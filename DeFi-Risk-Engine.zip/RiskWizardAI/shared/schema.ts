import { pgTable, text, serial, integer, boolean, timestamp, real, json, jsonb, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  walletAddress: text("wallet_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Portfolios table
export const portfolios = pgTable("portfolios", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  name: text("name").notNull(),
  totalValue: numeric("total_value").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Assets table
export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull().references(() => portfolios.id),
  name: text("name").notNull(),
  symbol: text("symbol").notNull(),
  type: text("type").notNull(), // e.g., "token", "liquidity", "lending", etc.
  value: numeric("value").notNull(),
  quantity: numeric("quantity").notNull(),
  price: numeric("price").notNull(),
  protocol: text("protocol"), // Which DeFi protocol it belongs to, if any
  chain: text("chain").notNull(), // e.g., "ethereum", "polygon", etc.
  chainId: integer("chain_id"), // Numeric chain ID
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Risk scores table
export const riskScores = pgTable("risk_scores", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull().references(() => portfolios.id),
  overallRiskScore: real("overall_risk_score").notNull(), // Overall risk score (0-100)
  valueAtRisk: numeric("value_at_risk").notNull(), // Value at Risk (VaR)
  sharpeRatio: real("sharpe_ratio").notNull(), // Sharpe ratio
  volatility: real("volatility").notNull(), // Portfolio volatility
  diversificationScore: real("diversification_score").notNull(), // Diversification score (0-100)
  impermanentLossRisk: real("impermanent_loss_risk"), // Risk from providing liquidity
  smartContractRisk: real("smart_contract_risk"), // Aggregate smart contract risk
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Protocol risk assessments
export const protocolRisks = pgTable("protocol_risks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  category: text("category").notNull(), // e.g., "DEX", "Lending", "Yield"
  riskScore: real("risk_score").notNull(), // 0-100 risk score
  auditStatus: text("audit_status").notNull(), // e.g., "Audited", "Unaudited"
  auditReports: jsonb("audit_reports"), // Links to audit reports
  tvl: numeric("tvl"), // Total Value Locked
  age: integer("age"), // Age in days
  exploitHistory: text("exploit_history"), // "None", "Minor", "Major"
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Portfolio history (for tracking portfolio value over time)
export const portfolioHistory = pgTable("portfolio_history", {
  id: serial("id").primaryKey(),
  portfolioId: integer("portfolio_id").notNull().references(() => portfolios.id),
  date: timestamp("date").notNull(),
  value: numeric("value").notNull(),
});

// Market data
export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  price: numeric("price").notNull(),
  volume24h: numeric("volume_24h"),
  marketCap: numeric("market_cap"),
  priceChange24h: real("price_change_24h"),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Smart Contract Risk Metrics
export const smartContractRiskMetrics = pgTable("smart_contract_risk_metrics", {
  id: serial("id").primaryKey(),
  protocolId: integer("protocol_id").notNull().references(() => protocolRisks.id),
  codeQualityScore: real("code_quality_score"), // Code quality assessment (0-100)
  securityScore: real("security_score"), // Security assessment (0-100)
  centralizedRiskScore: real("centralized_risk_score"), // Risk of centralization (0-100)
  upgradeabilityRisk: real("upgradeability_risk"), // Risk from upgradeability (0-100)
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

// Define schema validation with Zod
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  walletAddress: true,
});

export const insertPortfolioSchema = createInsertSchema(portfolios).pick({
  userId: true,
  name: true,
  totalValue: true,
});

export const insertAssetSchema = createInsertSchema(assets).pick({
  portfolioId: true,
  name: true,
  symbol: true,
  type: true,
  value: true,
  quantity: true,
  price: true,
  protocol: true,
  chain: true,
  chainId: true,
});

export const insertRiskScoreSchema = createInsertSchema(riskScores).pick({
  portfolioId: true,
  overallRiskScore: true,
  valueAtRisk: true,
  sharpeRatio: true,
  volatility: true,
  diversificationScore: true,
  impermanentLossRisk: true,
  smartContractRisk: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Portfolio = typeof portfolios.$inferSelect;
export type Asset = typeof assets.$inferSelect;
export type RiskScore = typeof riskScores.$inferSelect;
export type ProtocolRisk = typeof protocolRisks.$inferSelect;
