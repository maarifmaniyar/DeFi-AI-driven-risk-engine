import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { portfolios, riskScores, assets } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes - prefix all routes with /api
  
  // Get user portfolio
  app.get("/api/portfolio/:userId", async (req, res) => {
    try {
      const { userId } = req.params;
      
      // In a real implementation, we would fetch from the database
      // For demo purposes, return mock data
      const portfolioData = {
        id: 1,
        userId: parseInt(userId),
        totalValue: 152467.83,
        lastUpdated: new Date().toISOString()
      };
      
      res.json(portfolioData);
    } catch (error) {
      console.error("Error fetching portfolio:", error);
      res.status(500).json({ message: "Failed to fetch portfolio data" });
    }
  });

  // Get assets for a portfolio
  app.get("/api/portfolio/:portfolioId/assets", async (req, res) => {
    try {
      const { portfolioId } = req.params;
      
      // In a real implementation, we would fetch from the database
      // For now, return sample data
      const assetsData = [
        { id: 1, name: "Ethereum", symbol: "ETH", value: 58432.50, change: 5.2, quantity: 24.5, price: 2384.59 },
        { id: 2, name: "Bitcoin", symbol: "BTC", value: 42125.75, change: 2.8, quantity: 0.78, price: 54007.37 },
        { id: 3, name: "USD Coin", symbol: "USDC", value: 25000, change: 0, quantity: 25000, price: 1 },
        { id: 4, name: "Aave", symbol: "AAVE", value: 12500.33, change: -1.2, quantity: 120, price: 104.17 },
        { id: 5, name: "Uniswap", symbol: "UNI", value: 8240.15, change: -2.4, quantity: 1500, price: 5.49 },
        { id: 6, name: "Compound", symbol: "COMP", value: 6169.10, change: 1.7, quantity: 150, price: 41.13 }
      ];
      
      res.json(assetsData);
    } catch (error) {
      console.error("Error fetching assets:", error);
      res.status(500).json({ message: "Failed to fetch asset data" });
    }
  });

  // Get risk analysis for a portfolio
  app.get("/api/portfolio/:portfolioId/risk", async (req, res) => {
    try {
      const { portfolioId } = req.params;
      
      // In a real implementation, we would calculate based on real data
      const riskAnalysis = {
        riskScore: 57,
        valueAtRisk: 12742.56,
        sharpeRatio: 1.23,
        beta: 1.42,
        volatility: 0.32,
        diversificationScore: 68
      };
      
      res.json(riskAnalysis);
    } catch (error) {
      console.error("Error calculating risk:", error);
      res.status(500).json({ message: "Failed to calculate risk analysis" });
    }
  });

  // Get smart contract risk assessment
  app.get("/api/protocols/risk", async (req, res) => {
    try {
      const protocols = [
        { id: 1, name: "Uniswap V3", riskLevel: "Low", exposure: 8240.15 },
        { id: 2, name: "Aave V2", riskLevel: "Low", exposure: 12500.33 },
        { id: 3, name: "Compound V2", riskLevel: "Medium", exposure: 6169.10 },
        { id: 4, name: "SushiSwap", riskLevel: "Medium", exposure: 2450.75 },
        { id: 5, name: "Curve Finance", riskLevel: "Low", exposure: 3270.45 },
        { id: 6, name: "Balancer V2", riskLevel: "Medium", exposure: 1840.32 },
        { id: 7, name: "Yearn Finance", riskLevel: "High", exposure: 1640.87 }
      ];
      
      res.json(protocols);
    } catch (error) {
      console.error("Error fetching protocol risks:", error);
      res.status(500).json({ message: "Failed to fetch protocol risk data" });
    }
  });

  // Get portfolio history
  app.get("/api/portfolio/:portfolioId/history", async (req, res) => {
    try {
      const { portfolioId } = req.params;
      const { period = "30d" } = req.query;
      
      // Generate portfolio history data
      const history = generatePortfolioHistory(period as string);
      
      res.json(history);
    } catch (error) {
      console.error("Error fetching portfolio history:", error);
      res.status(500).json({ message: "Failed to fetch portfolio history" });
    }
  });

  // Get market data
  app.get("/api/market/trends", async (req, res) => {
    try {
      const marketTrends = [
        {
          id: 1,
          name: "Bitcoin",
          symbol: "BTC",
          color: "#F7931A",
          data: generatePriceHistory(50000, 0.10, 0.05)
        },
        {
          id: 2,
          name: "Ethereum",
          symbol: "ETH",
          color: "#627EEA",
          data: generatePriceHistory(2500, 0.15, 0.08)
        },
        {
          id: 3,
          name: "DeFi Index",
          symbol: "DPI",
          color: "#2775CA",
          data: generatePriceHistory(10000, 0.20, -0.02)
        }
      ];
      
      res.json(marketTrends);
    } catch (error) {
      console.error("Error fetching market trends:", error);
      res.status(500).json({ message: "Failed to fetch market data" });
    }
  });

  // Get wallet assets (for MetaMask integration)
  app.get("/api/wallet/:address", async (req, res) => {
    try {
      const { address } = req.params;
      
      // In a real app, we would call an API like Moralis, Alchemy, or Etherscan
      // to get real wallet data from the blockchain
      if (!address || address.length !== 42) {
        return res.status(400).json({ message: "Invalid wallet address" });
      }
      
      const walletData = {
        address,
        balances: [
          { token: "ETH", balance: "1.245", value: 2953.41 },
          { token: "USDC", balance: "5000.00", value: 5000.00 },
          { token: "AAVE", balance: "10.5", value: 1093.80 }
        ],
        totalValue: 9047.21
      };
      
      res.json(walletData);
    } catch (error) {
      console.error("Error fetching wallet data:", error);
      res.status(500).json({ message: "Failed to fetch wallet data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to generate portfolio history
function generatePortfolioHistory(period: string) {
  const days = period === "7d" ? 7 : period === "30d" ? 30 : period === "90d" ? 90 : 365;
  const history = [];
  const startValue = 140000;
  const volatility = 0.015;
  const trend = 0.001;
  
  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - (days - i));
    
    const randomFactor = (Math.random() - 0.5) * volatility;
    const trendFactor = trend * i;
    const value = startValue * (1 + randomFactor + trendFactor) + i * 500;
    
    history.push({
      date: date.toISOString().split('T')[0],
      value: parseFloat(value.toFixed(2))
    });
  }
  
  return history;
}

// Helper function to generate price history data
function generatePriceHistory(basePrice: number, volatility: number, trend: number) {
  const days = 30;
  const history = [];
  
  for (let i = 0; i < days; i++) {
    const date = new Date();
    date.setDate(date.getDate() - (days - i));
    
    const randomFactor = (Math.random() - 0.5) * volatility;
    const trendFactor = trend * i / days;
    const value = basePrice * (1 + randomFactor + trendFactor);
    
    history.push({
      date: date.toISOString().split('T')[0],
      value: parseFloat(value.toFixed(2))
    });
  }
  
  return history;
}
