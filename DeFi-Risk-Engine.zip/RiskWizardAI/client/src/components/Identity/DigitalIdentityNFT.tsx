import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { 
  Fingerprint, 
  Shield, 
  Star, 
  Lock, 
  UserCheck, 
  Key, 
  AlertTriangle, 
  CreditCard, 
  Eye, 
  EyeOff,
  Download, 
  Check, 
  Share2
} from "lucide-react";
import { useWallet } from "@/lib/stores/useWallet";

// Sample credit score data - in a real app, this would come from an API
const CREDIT_SCORE_DATA = {
  score: 742,
  history: [
    { month: "May", score: 742 },
    { month: "Apr", score: 738 },
    { month: "Mar", score: 735 },
    { month: "Feb", score: 729 },
    { month: "Jan", score: 726 },
    { month: "Dec", score: 720 },
  ],
  factors: [
    { name: "Payment History", score: 93, weight: 35 },
    { name: "Credit Utilization", score: 85, weight: 30 },
    { name: "Credit Age", score: 78, weight: 15 },
    { name: "Account Mix", score: 70, weight: 10 },
    { name: "Recent Inquiries", score: 95, weight: 10 }
  ],
  recommendations: [
    "Maintain current payment schedule on all accounts",
    "Consider decreasing credit utilization by 5-10%",
    "Avoid opening multiple new credit accounts in short periods"
  ]
};

// Identity verification statuses
const VERIFICATION_STATUSES = {
  kyc: { status: "verified", date: "2025-05-01", provider: "Veriff" },
  aml: { status: "verified", date: "2025-05-01", provider: "Chainalysis" },
  income: { status: "pending", date: null, provider: null },
  education: { status: "not_started", date: null, provider: null },
  employment: { status: "verified", date: "2025-04-15", provider: "Workday" }
};

// NFT metadata samples
const NFT_METADATA = {
  standard: "ERC-721",
  tokenId: "ZK-ID-73629",
  blockchain: "Polygon",
  minted: "2025-05-10T14:32:18Z",
  lastUpdated: "2025-05-15T09:14:23Z",
  dataHash: "0x8f23e3a7c3c0c0f1d9d2c0b7e7b6b5a4a3a2a1a0a9a8a7a6a5a4a3a2a1a0",
  encryptionScheme: "ECIES with secp256k1",
  permissions: {
    creditScore: true,
    identityBasics: true,
    financialHistory: true,
    educationCredentials: false,
    employmentHistory: true
  }
};

// Component for credit score visualization
function CreditScoreDisplay() {
  const { score, factors } = CREDIT_SCORE_DATA;
  
  // Color based on score range
  const getScoreColor = (score: number) => {
    if (score >= 740) return "text-green-500";
    if (score >= 670) return "text-yellow-500";
    if (score >= 580) return "text-orange-500";
    return "text-red-500";
  };
  
  // Score range description
  const getScoreDescription = (score: number) => {
    if (score >= 800) return "Excellent";
    if (score >= 740) return "Very Good";
    if (score >= 670) return "Good";
    if (score >= 580) return "Fair";
    return "Poor";
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center text-center mb-4">
        <div className="relative h-32 w-32">
          <div className="absolute inset-0 flex items-center justify-center">
            <span className={`text-4xl font-bold ${getScoreColor(score)}`}>{score}</span>
          </div>
          <svg className="h-32 w-32" viewBox="0 0 100 100">
            <circle 
              cx="50" 
              cy="50" 
              r="45" 
              fill="none" 
              stroke="hsl(var(--muted))" 
              strokeWidth="10" 
            />
            <circle 
              cx="50" 
              cy="50" 
              r="45" 
              fill="none" 
              stroke="hsl(var(--primary))" 
              strokeWidth="10" 
              strokeDasharray="282.7" 
              strokeDashoffset={282.7 - (282.7 * (score / 850))}
              transform="rotate(-90 50 50)" 
            />
          </svg>
        </div>
        <div className="mt-2">
          <span className={`text-sm font-medium ${getScoreColor(score)}`}>
            {getScoreDescription(score)}
          </span>
        </div>
      </div>
      
      <div className="space-y-3">
        {factors.map((factor, index) => (
          <div key={index} className="space-y-1">
            <div className="flex justify-between text-sm">
              <span>{factor.name}</span>
              <span className="font-medium">{factor.score}/100</span>
            </div>
            <div className="relative h-2">
              <div className="absolute inset-0 bg-muted rounded-full"></div>
              <div 
                className={`absolute h-2 rounded-full bg-primary`}
                style={{ width: `${factor.score}%`, opacity: 0.5 + (0.5 * factor.weight / 100) }}
              ></div>
            </div>
            <div className="text-xs text-muted-foreground">
              Impact: {factor.weight}%
            </div>
          </div>
        ))}
      </div>
      
      <div className="space-y-2">
        <h4 className="text-sm font-medium">Recommendations</h4>
        <ul className="text-sm space-y-1 text-muted-foreground">
          {CREDIT_SCORE_DATA.recommendations.map((recommendation, index) => (
            <li key={index} className="flex items-baseline space-x-2">
              <span className="text-green-500">•</span>
              <span>{recommendation}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

// Component for verification status
function VerificationStatus({ type, status }: { type: string, status: any }) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-green-600">Verified</Badge>;
      case "pending":
        return <Badge className="bg-yellow-500">Pending</Badge>;
      case "not_started":
        return <Badge className="bg-secondary">Not Started</Badge>;
      default:
        return <Badge className="bg-secondary">Unknown</Badge>;
    }
  };
  
  return (
    <div className="flex justify-between items-center py-3 border-b border-border last:border-0">
      <div className="space-y-1">
        <div className="font-medium capitalize">{type} Verification</div>
        {status.status === "verified" && (
          <div className="text-xs text-muted-foreground">
            Verified on {status.date} via {status.provider}
          </div>
        )}
      </div>
      <div className="flex items-center space-x-2">
        {getStatusBadge(status.status)}
        {status.status !== "verified" && (
          <Button variant="outline" size="sm">Verify</Button>
        )}
      </div>
    </div>
  );
}

// NFT Metadata display component
function NFTMetadataDisplay({ showSensitive }: { showSensitive: boolean }) {
  return (
    <div className="space-y-4">
      <div className="p-4 border rounded-md border-dashed">
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <div className="text-muted-foreground">NFT Standard</div>
            <div className="font-medium">{NFT_METADATA.standard}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Token ID</div>
            <div className="font-medium">{NFT_METADATA.tokenId}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Blockchain</div>
            <div className="font-medium">{NFT_METADATA.blockchain}</div>
          </div>
          <div>
            <div className="text-muted-foreground">Minted</div>
            <div className="font-medium">{new Date(NFT_METADATA.minted).toLocaleDateString()}</div>
          </div>
          {showSensitive && (
            <>
              <div className="col-span-2">
                <div className="text-muted-foreground">Data Hash</div>
                <div className="font-mono text-xs break-all">{NFT_METADATA.dataHash}</div>
              </div>
              <div className="col-span-2">
                <div className="text-muted-foreground">Encryption Scheme</div>
                <div className="font-medium">{NFT_METADATA.encryptionScheme}</div>
              </div>
            </>
          )}
          <div className="col-span-2">
            <div className="text-muted-foreground">Data Permissions</div>
            <div className="mt-1 flex flex-wrap gap-1">
              {Object.entries(NFT_METADATA.permissions).map(([key, enabled]) => (
                <Badge key={key} variant={enabled ? "default" : "outline"}>
                  {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function DigitalIdentityNFT() {
  const { isConnected, address } = useWallet();
  const [showSensitiveData, setShowSensitiveData] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  
  // Toggle data sharing permissions
  const togglePermission = (key: string) => {
    // In a real app, this would update blockchain permissions
    console.log(`Toggling permission for ${key}`);
  };
  
  // Sharing with DeFi providers
  const shareWithProvider = (providerId: string) => {
    setSelectedProvider(providerId);
  };
  
  const shortenAddress = (addr: string) => {
    return addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : '';
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Digital Identity</h2>
          <p className="text-muted-foreground">
            Manage your tokenized identity and credit score
          </p>
        </div>
        <Button>
          <Fingerprint className="mr-2 h-4 w-4" />
          Create New Identity Token
        </Button>
      </div>
      
      {!isConnected ? (
        <Alert className="bg-secondary/50">
          <Fingerprint className="h-4 w-4" />
          <AlertDescription>
            Connect your wallet to access your digital identity NFT
          </AlertDescription>
        </Alert>
      ) : (
        <>
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Shield className="mr-2 h-5 w-5 text-primary" />
                  Identity Credentials
                </CardTitle>
                <CardDescription>
                  Your verified identity credentials and credit score
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Tabs defaultValue="credit" className="w-full">
                  <div className="px-6">
                    <TabsList className="w-full">
                      <TabsTrigger value="credit" className="flex-1">Credit Score</TabsTrigger>
                      <TabsTrigger value="verification" className="flex-1">Verification</TabsTrigger>
                      <TabsTrigger value="nft" className="flex-1">NFT Metadata</TabsTrigger>
                    </TabsList>
                  </div>
                  
                  <TabsContent value="credit" className="mt-0">
                    <div className="px-6 py-4">
                      <CreditScoreDisplay />
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="verification" className="mt-0">
                    <div className="px-6 py-4">
                      <div className="space-y-1 mb-4">
                        <h3 className="font-medium">Verification Status</h3>
                        <p className="text-sm text-muted-foreground">
                          Your identity verification status for different data categories
                        </p>
                      </div>
                      
                      <div>
                        {Object.entries(VERIFICATION_STATUSES).map(([type, status]) => (
                          <VerificationStatus 
                            key={type} 
                            type={type} 
                            status={status} 
                          />
                        ))}
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="nft" className="mt-0">
                    <div className="px-6 py-4">
                      <div className="flex justify-between items-center mb-4">
                        <div className="space-y-1">
                          <h3 className="font-medium">NFT Token Metadata</h3>
                          <p className="text-sm text-muted-foreground">
                            Your identity token is securely stored on the blockchain
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Label htmlFor="show-sensitive" className="text-xs">
                            Show Sensitive Data
                          </Label>
                          <Switch 
                            id="show-sensitive" 
                            checked={showSensitiveData}
                            onCheckedChange={setShowSensitiveData}
                          />
                        </div>
                      </div>
                      
                      <NFTMetadataDisplay showSensitive={showSensitiveData} />
                      
                      <div className="flex items-center mt-4 space-x-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <Download className="mr-2 h-4 w-4" />
                          Export Metadata
                        </Button>
                        <Button variant="default" size="sm" className="flex-1">
                          <Key className="mr-2 h-4 w-4" />
                          Verify on Explorer
                        </Button>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="border-t px-6 py-4">
                <div className="flex justify-between items-center w-full">
                  <span className="text-xs text-muted-foreground">
                    Token Owner: {shortenAddress(address)}
                  </span>
                  <Badge>ZK-Powered</Badge>
                </div>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Share2 className="mr-2 h-5 w-5 text-primary" />
                  Data Sharing
                </CardTitle>
                <CardDescription>
                  Control how your identity data is shared
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <h3 className="text-sm font-medium">Data Permission Settings</h3>
                  
                  {Object.entries(NFT_METADATA.permissions).map(([key, value]) => (
                    <div key={key} className="flex items-center justify-between">
                      <Label 
                        htmlFor={`permission-${key}`} 
                        className="text-sm flex-1 cursor-pointer"
                      >
                        {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                      </Label>
                      <Switch
                        id={`permission-${key}`}
                        checked={value as boolean}
                        onCheckedChange={() => togglePermission(key)}
                      />
                    </div>
                  ))}
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h3 className="text-sm font-medium">Share With DeFi Providers</h3>
                  <p className="text-xs text-muted-foreground">
                    Grant temporary access to lending platforms and financial services
                  </p>
                  
                  <div className="space-y-2">
                    <div 
                      className={`rounded-md border p-3 cursor-pointer transition-colors ${
                        selectedProvider === 'aave' ? 'border-primary bg-primary/5' : ''
                      }`}
                      onClick={() => shareWithProvider('aave')}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="bg-blue-100 rounded-full p-1.5">
                            <div className="h-5 w-5 rounded-full bg-blue-500"></div>
                          </div>
                          <div>
                            <div className="font-medium">Aave</div>
                            <div className="text-xs text-muted-foreground">
                              Lending & Borrowing Protocol
                            </div>
                          </div>
                        </div>
                        {selectedProvider === 'aave' && (
                          <Check className="h-4 w-4 text-primary" />
                        )}
                      </div>
                    </div>
                    
                    <div 
                      className={`rounded-md border p-3 cursor-pointer transition-colors ${
                        selectedProvider === 'compound' ? 'border-primary bg-primary/5' : ''
                      }`}
                      onClick={() => shareWithProvider('compound')}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="bg-green-100 rounded-full p-1.5">
                            <div className="h-5 w-5 rounded-full bg-green-500"></div>
                          </div>
                          <div>
                            <div className="font-medium">Compound</div>
                            <div className="text-xs text-muted-foreground">
                              Algorithmic Money Market
                            </div>
                          </div>
                        </div>
                        {selectedProvider === 'compound' && (
                          <Check className="h-4 w-4 text-primary" />
                        )}
                      </div>
                    </div>
                    
                    <div 
                      className={`rounded-md border p-3 cursor-pointer transition-colors ${
                        selectedProvider === 'maker' ? 'border-primary bg-primary/5' : ''
                      }`}
                      onClick={() => shareWithProvider('maker')}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <div className="bg-yellow-100 rounded-full p-1.5">
                            <div className="h-5 w-5 rounded-full bg-yellow-500"></div>
                          </div>
                          <div>
                            <div className="font-medium">MakerDAO</div>
                            <div className="text-xs text-muted-foreground">
                              Decentralized Credit Platform
                            </div>
                          </div>
                        </div>
                        {selectedProvider === 'maker' && (
                          <Check className="h-4 w-4 text-primary" />
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {selectedProvider && (
                    <div className="rounded-md bg-primary/10 p-3 mt-3">
                      <h4 className="text-sm font-medium flex items-center">
                        <UserCheck className="h-4 w-4 mr-1 text-primary" />
                        Data Sharing Enabled
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        Your tokenized credit score and verification status will be shared with {
                          selectedProvider === 'aave' ? 'Aave' : 
                          selectedProvider === 'compound' ? 'Compound' : 
                          'MakerDAO'
                        }. You can revoke access at any time.
                      </p>
                      <Button variant="secondary" size="sm" className="mt-2 w-full">
                        <Lock className="h-3 w-3 mr-1" /> Access Controls
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="border-t px-6 py-4">
                <Alert variant="destructive" className="w-full">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    Never share your private keys or seed phrases with any service.
                  </AlertDescription>
                </Alert>
              </CardFooter>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Cross-Platform Lending Opportunities</CardTitle>
              <CardDescription>
                Lending opportunities available based on your tokenized credit score
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="rounded-md border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Star className="h-5 w-5 text-blue-500" />
                      <h3 className="font-medium">Aave Credit Line</h3>
                    </div>
                    <Badge>Best Rate</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Interest Rate</span>
                      <span className="font-medium text-green-500">3.2% APR</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Max Borrowing</span>
                      <span className="font-medium">$25,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Collateral Needed</span>
                      <span className="font-medium">25%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Term Length</span>
                      <span className="font-medium">Flexible</span>
                    </div>
                  </div>
                  <Button className="w-full mt-4">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Apply Now
                  </Button>
                </div>
                
                <div className="rounded-md border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Star className="h-5 w-5 text-green-500" />
                      <h3 className="font-medium">Compound Loan</h3>
                    </div>
                    <Badge variant="outline">Popular</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Interest Rate</span>
                      <span className="font-medium">4.1% APR</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Max Borrowing</span>
                      <span className="font-medium">$30,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Collateral Needed</span>
                      <span className="font-medium">20%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Term Length</span>
                      <span className="font-medium">Up to 12 months</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-4">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Apply Now
                  </Button>
                </div>
                
                <div className="rounded-md border p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <Star className="h-5 w-5 text-yellow-500" />
                      <h3 className="font-medium">Maker Vault</h3>
                    </div>
                    <Badge variant="outline">High Limit</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Interest Rate</span>
                      <span className="font-medium">4.8% APR</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Max Borrowing</span>
                      <span className="font-medium">$50,000</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Collateral Needed</span>
                      <span className="font-medium">30%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Term Length</span>
                      <span className="font-medium">Up to 24 months</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-4">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Apply Now
                  </Button>
                </div>
              </div>
              
              <div className="rounded-md bg-muted p-4 mt-6">
                <h3 className="font-medium text-sm mb-2">How Cross-Platform Lending Works</h3>
                <p className="text-sm text-muted-foreground">
                  Your tokenized credit score and identity verification are stored as NFTs, allowing you to securely share 
                  your creditworthiness across multiple DeFi platforms without exposing sensitive personal data. 
                  Zero-knowledge proofs enable lenders to verify your credentials without seeing the actual data.
                </p>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}