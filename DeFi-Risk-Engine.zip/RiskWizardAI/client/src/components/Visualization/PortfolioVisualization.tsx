import { useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls } from "@react-three/drei";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Maximize2, Minimize2 } from "lucide-react";
import { useWallet } from "@/lib/stores/useWallet";
import { usePortfolio } from "@/lib/stores/usePortfolio";
import ThreeDBarChart from "./ThreeDBarChart";
import RiskHeatmap from "./RiskHeatmap";

type VisualizationType = "barchart" | "heatmap";

export default function PortfolioVisualization() {
  const { isConnected } = useWallet();
  const { assets, assetsByChain } = usePortfolio();
  const [visualizationType, setVisualizationType] = useState<VisualizationType>("barchart");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });
  
  useEffect(() => {
    const handleResize = () => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };
    
    // Initial size
    handleResize();
    
    // Add resize listener
    window.addEventListener('resize', handleResize);
    
    // Clean up
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };
  
  if (!isConnected) {
    return (
      <Alert className="mt-4">
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Connect your wallet to view your portfolio visualization.
        </AlertDescription>
      </Alert>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Portfolio Visualization</h2>
          <p className="text-muted-foreground">
            Interactive 3D visualization of your DeFi portfolio
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select 
            value={visualizationType} 
            onValueChange={(value) => setVisualizationType(value as VisualizationType)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select visualization" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="barchart">3D Bar Chart</SelectItem>
              <SelectItem value="heatmap">Risk Heatmap</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" onClick={toggleFullscreen}>
            {isFullscreen ? (
              <Minimize2 className="h-5 w-5" />
            ) : (
              <Maximize2 className="h-5 w-5" />
            )}
          </Button>
        </div>
      </div>
      
      <div 
        className={`${isFullscreen ? 'fixed inset-0 z-40 p-0' : 'relative h-[600px]'}`}
      >
        <div className="absolute inset-0 flex">
          <Canvas
            camera={{ position: [15, 15, 15], fov: 40 }}
            gl={{ antialias: true }}
          >
            <ambientLight intensity={0.5} />
            <directionalLight position={[10, 10, 10]} intensity={0.7} />
            <directionalLight position={[-10, -10, -10]} intensity={0.3} />
            
            {visualizationType === "barchart" && (
              <ThreeDBarChart 
                data={visualizationType === "barchart" ? assets : assetsByChain} 
                isFullscreen={isFullscreen}
              />
            )}
            
            {visualizationType === "heatmap" && (
              <RiskHeatmap 
                isFullscreen={isFullscreen}
              />
            )}
            
            <OrbitControls 
              minDistance={10} 
              maxDistance={50}
              maxPolarAngle={Math.PI / 2} 
              enablePan={true}
            />
          </Canvas>
        </div>
        
        {!isFullscreen && (
          <Card className="absolute bottom-4 right-4 w-64 bg-background/80 backdrop-blur-sm">
            <CardHeader className="p-3">
              <CardTitle className="text-sm">Visualization Guide</CardTitle>
              <CardDescription className="text-xs">
                {visualizationType === "barchart" 
                  ? "Each bar represents an asset in your portfolio" 
                  : "Colors represent risk levels across protocols"}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-3 pt-0">
              <ul className="text-xs space-y-1">
                <li>• Click and drag to rotate</li>
                <li>• Scroll to zoom in/out</li>
                <li>• Use right-click to pan</li>
                {visualizationType === "barchart" && (
                  <li>• Bar height represents value</li>
                )}
                {visualizationType === "heatmap" && (
                  <li>• Redder colors = higher risk</li>
                )}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
