import { useRef, useMemo } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { useTheme } from "next-themes";
import { Asset, AssetByChain } from "@/lib/stores/usePortfolio";

type ThreeDBarChartProps = {
  data: Asset[] | AssetByChain[];
  isFullscreen: boolean;
};

export default function ThreeDBarChart({ data, isFullscreen }: ThreeDBarChartProps) {
  const groupRef = useRef<THREE.Group>(null);
  const { theme } = useTheme();
  
  // Colors
  const colorPrimary = "#22d3ee"; // cyan-400
  const colorSecondary = "#0ea5e9"; // sky-500
  const colorTertiary = "#3b82f6"; // blue-500
  const colorAccent = "#8b5cf6"; // violet-500
  const colorAxis = theme === "dark" ? "#71717a" : "#a1a1aa"; // zinc-500/400
  
  // Set up the grid and axes
  const gridSize = 20;
  const maxBarHeight = 15;
  
  // Normalize data for the visualization
  const maxValue = Math.max(...data.map(item => typeof item.value === 'number' ? item.value : 0));
  
  const bars = useMemo(() => {
    // Scale for positioning
    const spacing = 2;
    const totalWidth = (data.length - 1) * spacing;
    const startX = -totalWidth / 2;
    
    return data.map((item, index) => {
      // Make sure the height is proportional to the value
      const heightRatio = maxValue > 0 ? ((typeof item.value === 'number' ? item.value : 0) / maxValue) : 0;
      const height = heightRatio * maxBarHeight;
      
      // Position
      const x = startX + index * spacing;
      const y = height / 2; // Center in Y
      const z = 0; // All bars at the same Z
      
      // Color based on index (cycle through colors)
      const colors = [colorPrimary, colorSecondary, colorTertiary, colorAccent];
      const color = colors[index % colors.length];
      
      return {
        position: [x, y, z] as [number, number, number],
        height,
        name: item.name,
        value: typeof item.value === 'number' ? item.value : 0,
        color,
        index
      };
    });
  }, [data, maxValue, colorPrimary, colorSecondary, colorTertiary, colorAccent]);
  
  // Rotation animation
  useFrame((state, delta) => {
    if (groupRef.current) {
      // Gentle auto-rotation
      groupRef.current.rotation.y += delta * 0.05;
    }
  });
  
  return (
    <group ref={groupRef}>
      {/* Chart base */}
      <mesh position={[0, 0, 0]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[gridSize, gridSize]} />
        <meshStandardMaterial color={theme === "dark" ? "#1e293b" : "#e2e8f0"} />
      </mesh>
      
      {/* X Axis */}
      <line>
        <bufferGeometry
          attach="geometry"
          attributes={{
            position: new THREE.BufferAttribute(
              new Float32Array([-gridSize/2, 0, 0, gridSize/2, 0, 0]),
              3
            )
          }}
        />
        <lineBasicMaterial color={colorAxis} linewidth={2} />
      </line>
      
      {/* Z Axis */}
      <line>
        <bufferGeometry
          attach="geometry"
          attributes={{
            position: new THREE.BufferAttribute(
              new Float32Array([0, 0, -gridSize/2, 0, 0, gridSize/2]),
              3
            )
          }}
        />
        <lineBasicMaterial color={colorAxis} linewidth={2} />
      </line>
      
      {/* Y Axis */}
      <line>
        <bufferGeometry
          attach="geometry"
          attributes={{
            position: new THREE.BufferAttribute(
              new Float32Array([0, 0, 0, 0, maxBarHeight, 0]),
              3
            )
          }}
        />
        <lineBasicMaterial color={colorAxis} linewidth={2} />
      </line>
      
      {/* Bars */}
      {bars.map((bar) => (
        <group key={bar.index} position={[bar.position[0], 0, bar.position[2]]}>
          {/* Bar */}
          <mesh position={[0, bar.height / 2, 0]} castShadow receiveShadow>
            <boxGeometry args={[1, bar.height, 1]} />
            <meshStandardMaterial color={bar.color} />
          </mesh>
          
          {/* Label */}
          <Text
            position={[0, -0.6, 0]}
            rotation={[-Math.PI / 2, 0, 0]}
            fontSize={0.4}
            color={theme === "dark" ? "#f8fafc" : "#0f172a"}
            anchorX="center"
            anchorY="middle"
            maxWidth={2}
          >
            {bar.name}
          </Text>
          
          {/* Value */}
          <Text
            position={[0, bar.height + 0.5, 0]}
            fontSize={0.5}
            color={theme === "dark" ? "#f8fafc" : "#0f172a"}
            anchorX="center"
            anchorY="middle"
          >
            ${bar.value.toLocaleString()}
          </Text>
        </group>
      ))}
      
      {/* Legend */}
      <Text
        position={[0, 0, -gridSize/2 - 1.5]}
        fontSize={0.8}
        color={theme === "dark" ? "#f8fafc" : "#0f172a"}
        anchorX="center"
        anchorY="middle"
        maxWidth={gridSize}
      >
        Portfolio Assets by Value
      </Text>
    </group>
  );
}
