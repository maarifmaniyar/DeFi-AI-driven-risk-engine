import { useRef, useMemo } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { Text } from "@react-three/drei";
import { useTheme } from "next-themes";
import { useRiskAnalysis } from "@/lib/stores/useRiskAnalysis";

interface RiskHeatmapProps {
  isFullscreen: boolean;
}

export default function RiskHeatmap({ isFullscreen }: RiskHeatmapProps) {
  const groupRef = useRef<THREE.Group>(null);
  const { theme } = useTheme();
  const { protocolRiskMap } = useRiskAnalysis();
  
  // Grid setup
  const gridSize = 10;
  const cellSize = 1.5;
  
  // Colors for heatmap
  const lowRiskColor = new THREE.Color("#10b981"); // emerald-500
  const mediumRiskColor = new THREE.Color("#f59e0b"); // amber-500
  const highRiskColor = new THREE.Color("#ef4444"); // red-500
  
  // Generate the heatmap cells
  const cells = useMemo(() => {
    const cells = [];
    
    if (protocolRiskMap.length > 0) {
      const rows = Math.ceil(Math.sqrt(protocolRiskMap.length));
      const cols = Math.ceil(protocolRiskMap.length / rows);
      
      const startX = -(cols * cellSize) / 2 + cellSize / 2;
      const startZ = -(rows * cellSize) / 2 + cellSize / 2;
      
      for (let i = 0; i < protocolRiskMap.length; i++) {
        const item = protocolRiskMap[i];
        const row = Math.floor(i / cols);
        const col = i % cols;
        
        const x = startX + col * cellSize;
        const z = startZ + row * cellSize;
        
        // Determine height based on exposure (value)
        const height = Math.max(0.1, (item.exposure / 10000) * 2);
        
        // Determine color based on risk score
        let color;
        if (item.riskScore < 30) {
          color = lowRiskColor;
        } else if (item.riskScore < 70) {
          color = mediumRiskColor;
        } else {
          color = highRiskColor;
        }
        
        cells.push({
          position: [x, height / 2, z] as [number, number, number],
          scale: [cellSize * 0.9, height, cellSize * 0.9] as [number, number, number],
          color,
          name: item.name,
          riskScore: item.riskScore,
          exposure: item.exposure
        });
      }
    }
    
    return cells;
  }, [protocolRiskMap, cellSize]);
  
  // Rotation animation
  useFrame((state, delta) => {
    if (groupRef.current) {
      // Gentle auto-rotation
      groupRef.current.rotation.y += delta * 0.1;
    }
  });
  
  return (
    <group ref={groupRef}>
      {/* Base grid */}
      <mesh 
        position={[0, -0.1, 0]} 
        rotation={[-Math.PI / 2, 0, 0]} 
        receiveShadow
      >
        <planeGeometry args={[gridSize, gridSize]} />
        <meshStandardMaterial 
          color={theme === "dark" ? "#0f172a" : "#f8fafc"} 
          wireframe={true}
        />
      </mesh>
      
      {/* Grid lines */}
      <gridHelper 
        args={[gridSize, gridSize, theme === "dark" ? "#64748b" : "#94a3b8"]} 
        position={[0, 0.01, 0]}
      />
      
      {/* Heatmap cells */}
      {cells.map((cell, index) => (
        <group key={index}>
          <mesh 
            position={cell.position} 
            castShadow 
            receiveShadow
          >
            <boxGeometry args={[1, 1, 1]} />
            <meshStandardMaterial 
              color={cell.color} 
              roughness={0.7}
              metalness={0.2}
            />
            <Text
              position={[0, cell.scale[1] / 2 + 0.2, 0]}
              fontSize={0.3}
              color="#ffffff"
              anchorX="center"
              anchorY="bottom"
              maxWidth={2}
            >
              {cell.name}
            </Text>
            <Text
              position={[0, cell.scale[1] / 2 + 0.5, 0]}
              fontSize={0.25}
              color="#ffffff"
              anchorX="center"
              anchorY="bottom"
              maxWidth={2}
            >
              Risk: {cell.riskScore}
            </Text>
          </mesh>
        </group>
      ))}
      
      {/* Legend */}
      <group position={[0, 0, -gridSize / 2 - 1]}>
        <Text
          position={[0, 0, 0]}
          rotation={[0, 0, 0]}
          fontSize={0.5}
          color={theme === "dark" ? "#f8fafc" : "#0f172a"}
          anchorX="center"
          anchorY="top"
        >
          Protocol Risk Heatmap
        </Text>
        
        <group position={[-2, -0.8, 0]}>
          <mesh position={[0, 0, 0]}>
            <boxGeometry args={[0.3, 0.3, 0.3]} />
            <meshStandardMaterial color={lowRiskColor} />
          </mesh>
          <Text
            position={[0.4, 0, 0]}
            fontSize={0.3}
            color={theme === "dark" ? "#f8fafc" : "#0f172a"}
            anchorX="left"
            anchorY="middle"
          >
            Low Risk
          </Text>
        </group>
        
        <group position={[0, -0.8, 0]}>
          <mesh position={[0, 0, 0]}>
            <boxGeometry args={[0.3, 0.3, 0.3]} />
            <meshStandardMaterial color={mediumRiskColor} />
          </mesh>
          <Text
            position={[0.4, 0, 0]}
            fontSize={0.3}
            color={theme === "dark" ? "#f8fafc" : "#0f172a"}
            anchorX="left"
            anchorY="middle"
          >
            Medium Risk
          </Text>
        </group>
        
        <group position={[2, -0.8, 0]}>
          <mesh position={[0, 0, 0]}>
            <boxGeometry args={[0.3, 0.3, 0.3]} />
            <meshStandardMaterial color={highRiskColor} />
          </mesh>
          <Text
            position={[0.4, 0, 0]}
            fontSize={0.3}
            color={theme === "dark" ? "#f8fafc" : "#0f172a"}
            anchorX="left"
            anchorY="middle"
          >
            High Risk
          </Text>
        </group>
      </group>
    </group>
  );
}
