import { useEffect } from "react";
import { AlertTriangle, ArrowDown, ArrowUp, BarChart3, Info, PieChart, Wallet } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import PortfolioOverview from "./PortfolioOverview";
import RiskMetrics from "./RiskMetrics";
import AssetAllocation from "./AssetAllocation";
import MarketTrends from "./MarketTrends";
import { useWallet } from "@/lib/stores/useWallet";
import { usePortfolio } from "@/lib/stores/usePortfolio";

export default function Dashboard() {
  const { isConnected } = useWallet();
  const { 
    portfolioValue, 
    portfolioChange, 
    loadPortfolioData,
    riskScore
  } = usePortfolio();
  
  useEffect(() => {
    if (isConnected) {
      loadPortfolioData();
    }
  }, [isConnected, loadPortfolioData]);
  
  const getRiskLabel = (score: number) => {
    if (score < 20) return "Very Low";
    if (score < 40) return "Low";
    if (score < 60) return "Moderate";
    if (score < 80) return "High";
    return "Very High";
  };
  
  const getRiskColor = (score: number) => {
    if (score < 20) return "text-green-500";
    if (score < 40) return "text-emerald-500";
    if (score < 60) return "text-yellow-500";
    if (score < 80) return "text-orange-500";
    return "text-red-500";
  };
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
          <p className="text-muted-foreground">
            Monitor your portfolio and assess your risk exposure
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline">Export Report</Button>
          <Button>
            <BarChart3 className="mr-2 h-4 w-4" />
            Run Analysis
          </Button>
        </div>
      </div>
      
      {!isConnected ? (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Connect your wallet to view your portfolio and risk assessment.
          </AlertDescription>
        </Alert>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Total Portfolio Value
                </CardTitle>
                <Wallet className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${portfolioValue.toLocaleString()}</div>
                <div className="flex items-center text-xs">
                  <span className={`flex items-center ${portfolioChange >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                    {portfolioChange >= 0 ? (
                      <ArrowUp className="mr-1 h-3 w-3" />
                    ) : (
                      <ArrowDown className="mr-1 h-3 w-3" />
                    )}
                    {Math.abs(portfolioChange).toFixed(2)}%
                  </span>
                  <span className="text-muted-foreground ml-2">vs. last month</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Risk Score
                </CardTitle>
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger>
                      <Info className="h-4 w-4 text-muted-foreground" />
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Risk score based on portfolio volatility, asset correlation, and market conditions</p>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              </CardHeader>
              <CardContent>
                <div className="flex items-baseline">
                  <div className="text-2xl font-bold">{riskScore}</div>
                  <span className={`ml-2 ${getRiskColor(riskScore)}`}>
                    {getRiskLabel(riskScore)}
                  </span>
                </div>
                <div className="mt-2 h-2 w-full rounded-full bg-secondary">
                  <div 
                    className="h-2 rounded-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500" 
                    style={{ width: `${riskScore}%` }}
                  ></div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Diversification Score
                </CardTitle>
                <PieChart className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">68/100</div>
                <p className="text-xs text-muted-foreground">
                  Moderate diversification across assets
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Smart Contract Risk
                </CardTitle>
                <AlertTriangle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-yellow-500">Medium</div>
                <p className="text-xs text-muted-foreground">
                  2 protocols with elevated risk
                </p>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="overview" className="space-y-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="risk">Risk Metrics</TabsTrigger>
              <TabsTrigger value="assets">Asset Allocation</TabsTrigger>
              <TabsTrigger value="market">Market Trends</TabsTrigger>
            </TabsList>
            <TabsContent value="overview" className="space-y-4">
              <PortfolioOverview />
            </TabsContent>
            <TabsContent value="risk" className="space-y-4">
              <RiskMetrics />
            </TabsContent>
            <TabsContent value="assets" className="space-y-4">
              <AssetAllocation />
            </TabsContent>
            <TabsContent value="market" className="space-y-4">
              <MarketTrends />
            </TabsContent>
          </Tabs>
        </>
      )}
    </div>
  );
}
