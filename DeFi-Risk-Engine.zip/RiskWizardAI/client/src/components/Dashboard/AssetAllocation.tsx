import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { usePortfolio } from "@/lib/stores/usePortfolio";
import { Progress } from "@/components/ui/progress";

export default function AssetAllocation() {
  const { assetAllocation, assetsByChain, assetTypes } = usePortfolio();
  
  // Colors for the pie chart
  const COLORS = [
    "hsl(var(--chart-1))",
    "hsl(var(--chart-2))",
    "hsl(var(--chart-3))",
    "hsl(var(--chart-4))",
    "hsl(var(--chart-5))",
  ];
  
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Asset Allocation</CardTitle>
          <CardDescription>
            Distribution of your portfolio by asset
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={assetAllocation}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, percent }) => `${name} (${(percent * 100).toFixed(0)}%)`}
                  labelLine={false}
                >
                  {assetAllocation.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={COLORS[index % COLORS.length]} 
                    />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(value) => [`$${value.toLocaleString()}`, 'Value']}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="rounded-lg border bg-background p-2 shadow-sm">
                          <div className="grid grid-cols-2 gap-2">
                            <div className="flex flex-col">
                              <span className="text-[0.70rem] uppercase text-muted-foreground">
                                Asset
                              </span>
                              <span className="font-bold text-foreground">
                                {data.name}
                              </span>
                            </div>
                            <div className="flex flex-col">
                              <span className="text-[0.70rem] uppercase text-muted-foreground">
                                Value
                              </span>
                              <span className="font-bold text-foreground">
                                ${data.value.toLocaleString()}
                              </span>
                            </div>
                            <div className="flex flex-col col-span-2">
                              <span className="text-[0.70rem] uppercase text-muted-foreground">
                                Percentage
                              </span>
                              <span className="font-bold text-foreground">
                                {data.percentage.toFixed(2)}%
                              </span>
                            </div>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-4 space-y-3">
            {assetAllocation.map((item, index) => (
              <div key={item.id} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div 
                    className="h-3 w-3 rounded-full mr-2" 
                    style={{ backgroundColor: COLORS[index % COLORS.length] }}
                  ></div>
                  <span className="text-sm">{item.name}</span>
                </div>
                <span className="text-sm font-medium">{item.percentage.toFixed(2)}%</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Blockchain Distribution</CardTitle>
          <CardDescription>
            Distribution of your assets across blockchains
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {assetsByChain.map((chain) => (
            <div key={chain.id} className="space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">{chain.name}</span>
                <span className="text-sm text-muted-foreground">
                  ${chain.value.toLocaleString()} ({chain.percentage.toFixed(2)}%)
                </span>
              </div>
              <Progress value={chain.percentage} />
            </div>
          ))}
        </CardContent>
      </Card>
      
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle>Asset Types</CardTitle>
          <CardDescription>
            Distribution by asset category
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Asset Type</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Percentage</TableHead>
                <TableHead>Risk Level</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assetTypes.map((type) => (
                <TableRow key={type.id}>
                  <TableCell className="font-medium">{type.name}</TableCell>
                  <TableCell>${type.value.toLocaleString()}</TableCell>
                  <TableCell>{type.percentage.toFixed(2)}%</TableCell>
                  <TableCell>
                    <span className={
                      type.riskLevel === 'Low' ? 'text-green-500' :
                      type.riskLevel === 'Medium' ? 'text-yellow-500' :
                      'text-red-500'
                    }>
                      {type.riskLevel}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
