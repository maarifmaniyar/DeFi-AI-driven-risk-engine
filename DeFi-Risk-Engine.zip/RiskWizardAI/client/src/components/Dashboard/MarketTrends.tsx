import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, TrendingDown, TrendingUp } from "lucide-react";
import { useRiskAnalysis } from "@/lib/stores/useRiskAnalysis";

export default function MarketTrends() {
  const { 
    marketTrends, 
    marketAlerts, 
    correlatedAssets, 
    loading
  } = useRiskAnalysis();

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="col-span-2">
        <CardHeader>
          <CardTitle>Market Trends</CardTitle>
          <CardDescription>
            30-day price trends for major assets in your portfolio
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {loading ? (
              <div className="h-full flex justify-center items-center">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  {marketTrends.map((asset) => (
                    <Line
                      key={asset.id}
                      type="monotone"
                      data={asset.data}
                      dataKey="value"
                      name={asset.name}
                      stroke={asset.color}
                      strokeWidth={2}
                      dot={false}
                      activeDot={{ r: 6 }}
                    />
                  ))}
                  <XAxis 
                    dataKey="date" 
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    tick={{ fontSize: 12 }}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `$${value}`}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="rounded-lg border bg-background p-2 shadow-sm">
                            <div className="mb-2 text-sm font-medium">
                              {new Date(label).toLocaleDateString()}
                            </div>
                            {payload.map((entry) => (
                              <div 
                                key={entry.name}
                                className="flex items-center justify-between gap-8 text-xs"
                              >
                                <div className="flex items-center">
                                  <div 
                                    className="h-2 w-2 rounded-full mr-1" 
                                    style={{ backgroundColor: entry.stroke }}
                                  />
                                  <span>{entry.name}</span>
                                </div>
                                <span className="font-medium">${Number(entry.value).toLocaleString()}</span>
                              </div>
                            ))}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                </LineChart>
              </ResponsiveContainer>
            )}
          </div>
          <div className="mt-4 flex flex-wrap gap-3">
            {marketTrends.map((asset) => (
              <div 
                key={asset.id} 
                className="flex items-center rounded-lg border px-3 py-1"
              >
                <div 
                  className="h-3 w-3 rounded-full mr-2" 
                  style={{ backgroundColor: asset.color }}
                />
                <span className="text-sm font-medium">{asset.name}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Market Alerts</CardTitle>
          <CardDescription>
            Recent significant market events
          </CardDescription>
        </CardHeader>
        <CardContent>
          {marketAlerts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <AlertCircle className="h-12 w-12 mb-2" />
              <p>No important market alerts at this time</p>
            </div>
          ) : (
            <div className="space-y-4">
              {marketAlerts.map((alert) => (
                <Alert key={alert.id} variant={alert.severity === 'high' ? 'destructive' : 'default'}>
                  {alert.severity === 'high' ? (
                    <AlertTriangle className="h-4 w-4" />
                  ) : alert.type === 'positive' ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  <AlertTitle className="text-sm font-medium">
                    {alert.title}
                  </AlertTitle>
                  <AlertDescription className="text-xs mt-1">
                    {alert.description}
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Correlated Assets</CardTitle>
          <CardDescription>
            Assets with high price correlation
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Assets</TableHead>
                <TableHead>Correlation</TableHead>
                <TableHead>Implication</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {correlatedAssets.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>
                    <div className="font-medium">{item.pair}</div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <span className="text-sm font-medium">{item.correlation.toFixed(2)}</span>
                      <div 
                        className="ml-2 h-2 w-16 rounded-full bg-secondary"
                      >
                        <div 
                          className="h-full rounded-full bg-primary"
                          style={{ width: `${Math.abs(item.correlation) * 100}%` }}
                        />
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {item.implication}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper component for empty state
function AlertCircle(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}
