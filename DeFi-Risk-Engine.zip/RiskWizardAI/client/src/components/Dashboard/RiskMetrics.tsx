import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useRiskAnalysis } from "@/lib/stores/useRiskAnalysis";
import { Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Bar, BarChart, Cell, ResponsiveContainer, XAxis, YAxis } from "recharts";

export default function RiskMetrics() {
  const { 
    riskMetrics, 
    volatilityByAsset, 
    smartContractRisks,
    loading 
  } = useRiskAnalysis();

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="col-span-2">
        <CardHeader>
          <CardTitle>Portfolio Risk Analysis</CardTitle>
          <CardDescription>
            Key risk indicators for your portfolio
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            {loading ? (
              <div className="col-span-3 flex justify-center py-8">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
              </div>
            ) : (
              <>
                {riskMetrics.map((metric) => (
                  <div key={metric.id} className="space-y-1">
                    <div className="flex items-center gap-1">
                      <h4 className="text-sm font-medium">{metric.name}</h4>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>{metric.description}</TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                    <div className="flex items-baseline space-x-2">
                      <span className="text-2xl font-bold">{metric.value}</span>
                      <span className={`text-xs ${
                        metric.status === 'good' ? 'text-green-500' : 
                        metric.status === 'warning' ? 'text-yellow-500' : 
                        'text-red-500'
                      }`}>
                        {metric.interpretation}
                      </span>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Volatility by Asset</CardTitle>
          <CardDescription>
            30-day volatility of your top assets
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={volatilityByAsset}
                margin={{
                  top: 5,
                  right: 20,
                  left: 20,
                  bottom: 50,
                }}
                layout="vertical"
              >
                <XAxis 
                  type="number" 
                  tickFormatter={(value) => `${value}%`}
                  domain={[0, 'dataMax']}
                />
                <YAxis 
                  type="category" 
                  dataKey="name" 
                  tickLine={false}
                  axisLine={false}
                  width={100}
                />
                <Bar dataKey="volatility" radius={[4, 4, 4, 4]}>
                  {volatilityByAsset.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={
                        entry.volatility < 25 ? "hsl(var(--chart-1))" :
                        entry.volatility < 50 ? "hsl(var(--chart-2))" :
                        entry.volatility < 75 ? "hsl(var(--chart-3))" :
                        "hsl(var(--chart-4))"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Smart Contract Risks</CardTitle>
          <CardDescription>
            Protocol security assessments
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="high">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="high">High</TabsTrigger>
              <TabsTrigger value="medium">Medium</TabsTrigger>
              <TabsTrigger value="low">Low</TabsTrigger>
            </TabsList>
            <TabsContent value="high">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Protocol</TableHead>
                    <TableHead>Risk Level</TableHead>
                    <TableHead>Exposure</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {smartContractRisks
                    .filter(item => item.riskLevel === 'High')
                    .map(item => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>
                          <span className="text-red-500 font-medium">High</span>
                        </TableCell>
                        <TableCell>${item.exposure.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  {smartContractRisks.filter(item => item.riskLevel === 'High').length === 0 && (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center text-muted-foreground py-4">
                        No high risk protocols found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>
            <TabsContent value="medium">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Protocol</TableHead>
                    <TableHead>Risk Level</TableHead>
                    <TableHead>Exposure</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {smartContractRisks
                    .filter(item => item.riskLevel === 'Medium')
                    .map(item => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>
                          <span className="text-yellow-500 font-medium">Medium</span>
                        </TableCell>
                        <TableCell>${item.exposure.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  {smartContractRisks.filter(item => item.riskLevel === 'Medium').length === 0 && (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center text-muted-foreground py-4">
                        No medium risk protocols found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>
            <TabsContent value="low">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Protocol</TableHead>
                    <TableHead>Risk Level</TableHead>
                    <TableHead>Exposure</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {smartContractRisks
                    .filter(item => item.riskLevel === 'Low')
                    .map(item => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>
                          <span className="text-green-500 font-medium">Low</span>
                        </TableCell>
                        <TableCell>${item.exposure.toLocaleString()}</TableCell>
                      </TableRow>
                    ))}
                  {smartContractRisks.filter(item => item.riskLevel === 'Low').length === 0 && (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center text-muted-foreground py-4">
                        No low risk protocols found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
