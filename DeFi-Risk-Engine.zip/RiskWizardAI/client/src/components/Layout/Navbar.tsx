import { useState } from "react";
import { useLocation } from "wouter";
import { Bell, ChevronDown, Menu, Moon, Search, Sun } from "lucide-react";
import { useTheme } from "next-themes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import Sidebar from "./Sidebar";
import ConnectWallet from "../WalletConnect/ConnectWallet";
import { useWallet } from "@/lib/stores/useWallet";

export default function Navbar() {
  const [, setLocation] = useLocation();
  const { theme, setTheme } = useTheme();
  const { isConnected, address } = useWallet();
  const [isSearchActive, setIsSearchActive] = useState(false);
  
  const pathMap: Record<string, string> = {
    "/": "Dashboard",
    "/visualization": "Portfolio Visualization",
    "/analytics": "Risk Analytics",
    "/settings": "Settings"
  };
  
  const [, pathname] = useLocation();
  const currentPath = pathMap[pathname] || "Not Found";
  
  const shortenAddress = (addr: string) => {
    return addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : '';
  };
  
  return (
    <header className="sticky top-0 z-30 border-b bg-card/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between px-4">
        <div className="flex md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="p-0 bg-sidebar">
              <Sidebar />
            </SheetContent>
          </Sheet>
        </div>
        
        <div className="flex-1 md:ml-0">
          <h1 className="text-xl font-semibold">{currentPath}</h1>
        </div>
        
        <div className="flex items-center gap-2">
          {isSearchActive ? (
            <div className="relative w-full max-w-sm mr-2">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search portfolios, assets..."
                className="w-full bg-background pl-8 focus-visible:ring-cyan-500"
                autoFocus
                onBlur={() => setIsSearchActive(false)}
              />
            </div>
          ) : (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsSearchActive(true)}
              className="hidden md:flex"
            >
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
          )}
          
          <Button variant="ghost" size="icon">
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notifications</span>
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                {theme === "dark" ? (
                  <Moon className="h-5 w-5" />
                ) : (
                  <Sun className="h-5 w-5" />
                )}
                <span className="sr-only">Toggle theme</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTheme("light")}>
                Light
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("dark")}>
                Dark
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTheme("system")}>
                System
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          {isConnected ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="ml-2 h-9 gap-1">
                  <div className="h-6 w-6 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500"></div>
                  <span className="hidden md:inline">{shortenAddress(address)}</span>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setLocation("/")}>
                  My Portfolio
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLocation("/settings")}>
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => useWallet.getState().disconnect()}>
                  Disconnect
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <ConnectWallet />
          )}
        </div>
      </div>
    </header>
  );
}
