import { Link, useRoute } from "wouter";
import { 
  BarChart3, 
  ChevronRight, 
  CloudLightning, 
  CreditCard, 
  Home, 
  Layers, 
  Settings, 
  Shield, 
  SquareStack,
  Fingerprint,
  Sparkles,
  FileText
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  title: string;
  isCollapsed?: boolean;
}

function NavItem({ href, icon, title, isCollapsed }: NavItemProps) {
  const [isActive] = useRoute(href);
  
  return (
    <TooltipProvider delayDuration={0}>
      <Tooltip>
        <TooltipTrigger asChild>
          <Link href={href}>
            <Button
              variant={isActive ? "secondary" : "ghost"}
              size="sm"
              className={cn(
                "w-full justify-start",
                isActive 
                  ? "bg-sidebar-accent text-sidebar-accent-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
                isCollapsed ? "px-2" : "px-3"
              )}
            >
              {icon}
              {!isCollapsed && <span className="ml-2">{title}</span>}
            </Button>
          </Link>
        </TooltipTrigger>
        {isCollapsed && <TooltipContent side="right">{title}</TooltipContent>}
      </Tooltip>
    </TooltipProvider>
  );
}

export default function Sidebar() {
  const isCollapsed = false; // Could be made togglable
  
  return (
    <aside
      className={cn(
        "flex flex-col border-r bg-sidebar text-sidebar-foreground",
        isCollapsed ? "w-16" : "w-64"
      )}
    >
      <div className="sticky top-0 z-10">
        <div className="flex h-16 items-center border-b px-4">
          {isCollapsed ? (
            <CloudLightning className="h-8 w-8 text-sidebar-primary" />
          ) : (
            <div className="flex items-center gap-2">
              <CloudLightning className="h-8 w-8 text-sidebar-primary" />
              <span className="text-lg font-bold text-sidebar-primary neon-glow">
                RiskVision
              </span>
            </div>
          )}
        </div>
        
        <div className="px-3 py-4">
          <div className="mb-4">
            <h3 className={cn(
              "mb-2 text-xs font-medium uppercase text-sidebar-foreground/50",
              isCollapsed && "sr-only"
            )}>
              Dashboard
            </h3>
            <nav className="flex flex-col gap-1">
              <NavItem
                href="/"
                icon={<Home className="h-4 w-4" />}
                title="Overview"
                isCollapsed={isCollapsed}
              />
              <NavItem
                href="/visualization"
                icon={<Layers className="h-4 w-4" />}
                title="Portfolio Visualization"
                isCollapsed={isCollapsed}
              />
            </nav>
          </div>
          
          <div className="mb-4">
            <h3 className={cn(
              "mb-2 text-xs font-medium uppercase text-sidebar-foreground/50",
              isCollapsed && "sr-only"
            )}>
              Analytics
            </h3>
            <nav className="flex flex-col gap-1">
              <NavItem
                href="/risk-analysis"
                icon={<BarChart3 className="h-4 w-4" />}
                title="Risk Analysis"
                isCollapsed={isCollapsed}
              />
              <NavItem
                href="/assets"
                icon={<SquareStack className="h-4 w-4" />}
                title="Assets"
                isCollapsed={isCollapsed}
              />
              <NavItem
                href="/defi-protocols"
                icon={<Shield className="h-4 w-4" />}
                title="DeFi Protocols"
                isCollapsed={isCollapsed}
              />
            </nav>
          </div>
          
          <div className="mb-4">
            <h3 className={cn(
              "mb-2 text-xs font-medium uppercase text-sidebar-foreground/50",
              isCollapsed && "sr-only"
            )}>
              Advanced Features
            </h3>
            <nav className="flex flex-col gap-1">
              <NavItem
                href="/ai"
                icon={<Sparkles className="h-4 w-4" />}
                title="AI Assistant"
                isCollapsed={isCollapsed}
              />
              <NavItem
                href="/compliance"
                icon={<FileText className="h-4 w-4" />}
                title="Compliance Rules"
                isCollapsed={isCollapsed}
              />
              <NavItem
                href="/identity"
                icon={<Fingerprint className="h-4 w-4" />}
                title="Digital Identity"
                isCollapsed={isCollapsed}
              />
            </nav>
          </div>
          
          <div className="mb-4">
            <h3 className={cn(
              "mb-2 text-xs font-medium uppercase text-sidebar-foreground/50",
              isCollapsed && "sr-only"
            )}>
              Account
            </h3>
            <nav className="flex flex-col gap-1">
              <NavItem
                href="/banking"
                icon={<CreditCard className="h-4 w-4" />}
                title="Banking"
                isCollapsed={isCollapsed}
              />
              <NavItem
                href="/settings"
                icon={<Settings className="h-4 w-4" />}
                title="Settings"
                isCollapsed={isCollapsed}
              />
            </nav>
          </div>
        </div>
      </div>
      
      {!isCollapsed && (
        <div className="mt-auto p-4">
          <div className="rounded-lg bg-sidebar-accent/20 p-4">
            <h4 className="font-medium text-white">Upgrade to Pro</h4>
            <p className="mt-1 text-xs text-sidebar-foreground/70">
              Get advanced risk insights and better portfolio analysis
            </p>
            <Link href="/upgrade">
              <Button className="mt-3 w-full bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90">
                Upgrade <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      )}
    </aside>
  );
}
