import { useState, useEffect } from "react";
import SpeechRecognition, { useSpeechRecognition } from "react-speech-recognition";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Mic, MicOff, Volume2, RefreshCw } from "lucide-react";
import { useWallet } from "@/lib/stores/useWallet";
import { usePortfolio } from "@/lib/stores/usePortfolio";
import { useRiskAnalysis } from "@/lib/stores/useRiskAnalysis";

// Voice commands map
const COMMANDS: Record<string, string[]> = {
  "show portfolio": ["show my portfolio", "display portfolio", "view my assets"],
  "risk analysis": ["analyze risk", "show risk", "risk assessment", "portfolio risk"],
  "market trends": ["show market trends", "market analysis", "market data"],
  "visualization": ["show visualization", "3d visualization", "portfolio visualization"],
  "connect wallet": ["connect my wallet", "link wallet", "connect metamask"],
  "disconnect wallet": ["disconnect wallet", "unlink wallet", "remove wallet"],
  "summary": ["give me a summary", "portfolio summary", "summarize my assets"],
  "compliance check": ["compliance check", "regulatory status", "check regulations", "compliance status"],
  "simulate market": ["simulate market", "market scenario", "what if analysis", "stress test"],
  "identity status": ["identity status", "id verification", "check identity", "verification status"],
  "investment advice": ["investment advice", "what should i invest in", "investment recommendations", "suggest investments"],
  "upgrade plan": ["upgrade plan", "premium features", "go pro", "upgrade subscription"],
  "defi protocols": ["defi protocols", "protocol risk", "show protocols", "protocol exposure"]
};

export default function VoiceAssistant() {
  const [isListening, setIsListening] = useState(false);
  const [response, setResponse] = useState<string>("");
  const [speaking, setSpeaking] = useState(false);
  const [history, setHistory] = useState<Array<{type: "command" | "response", text: string}>>([]);
  const { isConnected, address, balance } = useWallet();
  const { portfolioValue, portfolioChange, assets, riskScore } = usePortfolio();
  const { riskMetrics } = useRiskAnalysis();

  const { transcript, resetTranscript, browserSupportsSpeechRecognition } = useSpeechRecognition();

  useEffect(() => {
    if (transcript) {
      const command = identifyCommand(transcript.toLowerCase());
      if (command) {
        processCommand(command);
      }
    }
  }, [transcript]);

  if (!browserSupportsSpeechRecognition) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Voice Assistant</CardTitle>
          <CardDescription>
            Your browser doesn't support speech recognition
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Please use a modern browser like Chrome, Edge, or Safari to use the voice assistant feature.
          </p>
        </CardContent>
      </Card>
    );
  }

  const toggleListening = () => {
    if (isListening) {
      SpeechRecognition.stopListening();
      setIsListening(false);
    } else {
      resetTranscript();
      SpeechRecognition.startListening({ continuous: true });
      setIsListening(true);
    }
  };

  // Identify command from transcript
  const identifyCommand = (text: string): string | null => {
    for (const [command, phrases] of Object.entries(COMMANDS)) {
      if (phrases.some(phrase => text.includes(phrase))) {
        // Add to history
        setHistory(prev => [...prev, { type: "command", text }]);
        return command;
      }
    }
    return null;
  };

  // Process identified command
  const processCommand = (command: string) => {
    let responseText = "";

    switch (command) {
      case "show portfolio":
        responseText = `Your portfolio is currently valued at $${portfolioValue.toLocaleString()} which is ${portfolioChange >= 0 ? "up" : "down"} ${Math.abs(portfolioChange).toFixed(2)}% from last month. Your top assets are ${assets.slice(0, 3).map(a => a.name).join(", ")}.`;
        break;
      case "risk analysis":
        responseText = `Your portfolio risk score is ${riskScore} which is considered ${getRiskLevel(riskScore)}. `;
        if (riskMetrics.length > 0) {
          responseText += `Your Sharpe Ratio is ${riskMetrics.find(m => m.name === "Sharpe Ratio")?.value || "not available"} and your Value at Risk is ${riskMetrics.find(m => m.name === "VaR (95%)")?.value || "not available"}.`;
        }
        break;
      case "market trends":
        responseText = "Based on current market trends, crypto markets are showing moderate volatility. Bitcoin and Ethereum have stabilized over the past week, while DeFi tokens have experienced higher fluctuations.";
        break;
      case "visualization":
        responseText = "I've opened the portfolio visualization page where you can explore your assets in 3D. Use your mouse to rotate the view and scroll to zoom in and out.";
        // Navigate to visualization page
        window.location.href = "/visualization";
        break;
      case "connect wallet":
        if (!isConnected) {
          responseText = "Connecting your wallet now. Please confirm the connection in your wallet provider if prompted.";
          try {
            useWallet.getState().connect();
          } catch (error) {
            responseText = "There was an issue connecting your wallet. Please try connecting manually.";
          }
        } else {
          responseText = "Your wallet is already connected.";
        }
        break;
      case "disconnect wallet":
        if (isConnected) {
          responseText = "Disconnecting your wallet now.";
          useWallet.getState().disconnect();
        } else {
          responseText = "You don't have a wallet connected.";
        }
        break;
      case "summary":
        if (isConnected) {
          responseText = `Here's a summary of your portfolio: Total value is $${portfolioValue.toLocaleString()}. Your risk score is ${riskScore} which is ${getRiskLevel(riskScore)}. You have ${assets.length} assets in your portfolio, with ${assets[0].name} being your largest holding at $${assets[0].value.toLocaleString()}.`;
        } else {
          responseText = "Please connect your wallet to see your portfolio summary.";
        }
        break;
      case "compliance check":
        responseText = "Running compliance check against MiCA and FATF regulations. Your portfolio is currently 92% compliant with regulatory requirements. There are 3 minor issues to address: 1) Missing KYC verification for one connected wallet, 2) Exposure to a protocol with incomplete audit, and 3) Transactions with unverified smart contracts. Would you like to view detailed compliance reports?";
        // Navigate to compliance page
        setTimeout(() => {
          window.location.href = "/compliance";
        }, 5000);
        break;
      case "simulate market":
        responseText = "Opening the market scenario simulator where you can test how your portfolio would perform under different market conditions like crypto winter, DeFi hack, or regulatory changes.";
        // Navigate to AI page
        setTimeout(() => {
          window.location.href = "/ai";
        }, 3000);
        break;
      case "identity status":
        responseText = "Checking your digital identity NFT status. Your verification is complete with a trust score of 85/100. Your credit score and KYC verification are valid for another 120 days. Opening your digital identity dashboard now.";
        // Navigate to identity page
        setTimeout(() => {
          window.location.href = "/identity";
        }, 3000);
        break;
      case "investment advice":
        responseText = "Based on your current portfolio composition and risk profile, you might consider: 1) Increasing your stablecoin allocation to reduce volatility, 2) Diversifying into Layer 2 solutions which have shown strong growth potential, and 3) Reducing exposure to lending protocols without active governance participation. Would you like more personalized recommendations?";
        break;
      case "upgrade plan":
        responseText = "The Pro plan offers enhanced features including advanced AI market simulations, unlimited portfolio tracking, cross-chain analysis, and compliance automation. Opening the upgrade page now so you can view all available options.";
        // Navigate to upgrade page
        setTimeout(() => {
          window.location.href = "/upgrade";
        }, 3000);
        break;
      case "defi protocols":
        responseText = "Analyzing your DeFi protocol exposure. You currently have assets in 5 major protocols with varying risk levels. Aave shows low risk with proper insurance coverage, while your position in newer yield farming protocols shows elevated risk due to unaudited smart contracts. Opening the protocol risk dashboard for details.";
        // Navigate to defi protocols page
        setTimeout(() => {
          window.location.href = "/defi-protocols";
        }, 3000);
        break;
      default:
        responseText = "I'm sorry, I didn't understand that command. You can ask me to show your portfolio, analyze risk, show market trends, or open the 3D visualization. You can also say 'compliance check', 'simulate market', or 'upgrade plan' for advanced features.";
    }

    // Add response to history
    setHistory(prev => [...prev, { type: "response", text: responseText }]);
    setResponse(responseText);
    speakResponse(responseText);
  };

  // Convert response to speech
  const speakResponse = (text: string) => {
    if ('speechSynthesis' in window) {
      setSpeaking(true);
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.onend = () => setSpeaking(false);
      window.speechSynthesis.speak(utterance);
    }
  };

  // Helper function to get risk level description
  const getRiskLevel = (score: number) => {
    if (score < 20) return "very low risk";
    if (score < 40) return "low risk";
    if (score < 60) return "moderate risk";
    if (score < 80) return "high risk";
    return "very high risk";
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <Volume2 className="mr-2 h-5 w-5 text-primary" />
          Financial AI Assistant
        </CardTitle>
        <CardDescription>
          Use voice commands to interact with your portfolio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <ScrollArea className="h-[200px] rounded-md border p-4">
          {history.length === 0 ? (
            <div className="text-center text-muted-foreground py-12">
              <p>Your conversation history will appear here</p>
              <p className="text-xs mt-2">Try saying "Show my portfolio" or "Analyze risk"</p>
            </div>
          ) : (
            <div className="space-y-4">
              {history.map((item, index) => (
                <div key={index} className={`flex ${item.type === 'command' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`rounded-lg px-3 py-2 max-w-[80%] ${
                      item.type === 'command'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    <p className="text-sm">{item.text}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>

        <div className="flex items-center space-x-2">
          <Button
            variant={isListening ? "destructive" : "default"}
            className="w-full"
            onClick={toggleListening}
          >
            {isListening ? (
              <>
                <MicOff className="mr-2 h-4 w-4" />
                Stop Listening
              </>
            ) : (
              <>
                <Mic className="mr-2 h-4 w-4" />
                Start Listening
              </>
            )}
          </Button>
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => {
              resetTranscript();
              setHistory([]);
            }}
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>

        {isListening && (
          <div className="rounded-md bg-secondary p-3">
            <p className="text-sm font-medium">Listening...</p>
            <p className="text-xs text-muted-foreground mt-1">{transcript || "Say something..."}</p>
          </div>
        )}

        {speaking && (
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Volume2 className="h-4 w-4 animate-pulse" />
            <span>Speaking...</span>
          </div>
        )}

        <div className="rounded-md bg-muted p-3">
          <p className="text-sm font-medium">Try these commands:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-1 mt-1">
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1">Basic Commands:</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• "Show my portfolio"</li>
                <li>• "Analyze risk"</li>
                <li>• "Show market trends"</li>
                <li>• "Open visualization"</li>
                <li>• "Give me a summary"</li>
              </ul>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground mb-1">Advanced Commands:</p>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• "Compliance check"</li>
                <li>• "Simulate market"</li>
                <li>• "Identity status"</li>
                <li>• "Investment advice"</li>
                <li>• "Upgrade plan"</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}