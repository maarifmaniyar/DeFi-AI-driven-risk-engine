import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, TrendingDown, Info, RefreshCw, Play } from "lucide-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { usePortfolio } from "@/lib/stores/usePortfolio";

const SCENARIO_DESCRIPTIONS = {
  "crypto_winter": {
    title: "Crypto Winter",
    description: "Simulates an extended bear market with Bitcoin dropping 60%+ and altcoins following with 70-90% losses.",
    impacts: [
      { asset: "Bitcoin", impact: -65 },
      { asset: "Ethereum", impact: -75 },
      { asset: "DeFi tokens", impact: -85 },
      { asset: "Stablecoins", impact: -1 },
    ]
  },
  "defi_hack": {
    title: "Major DeFi Protocol Hack",
    description: "Simulates a significant security breach in a major DeFi protocol causing contagion across the ecosystem.",
    impacts: [
      { asset: "Bitcoin", impact: -15 },
      { asset: "Ethereum", impact: -25 },
      { asset: "DeFi tokens", impact: -60 },
      { asset: "Stablecoins", impact: -5 },
    ]
  },
  "eth_upgrade": {
    title: "Ethereum Major Upgrade Success",
    description: "Simulates a successful major Ethereum upgrade that improves scalability and reduces gas fees.",
    impacts: [
      { asset: "Bitcoin", impact: 5 },
      { asset: "Ethereum", impact: 40 },
      { asset: "DeFi tokens", impact: 30 },
      { asset: "Stablecoins", impact: 0 },
    ]
  },
  "regulation": {
    title: "Global Crypto Regulation",
    description: "Simulates the implementation of strict global cryptocurrency regulations.",
    impacts: [
      { asset: "Bitcoin", impact: -30 },
      { asset: "Ethereum", impact: -25 },
      { asset: "DeFi tokens", impact: -45 },
      { asset: "Stablecoins", impact: -10 },
    ]
  },
  "institutional": {
    title: "Institutional Adoption Wave",
    description: "Simulates a wave of institutional investors and corporations adopting cryptocurrencies.",
    impacts: [
      { asset: "Bitcoin", impact: 80 },
      { asset: "Ethereum", impact: 60 },
      { asset: "DeFi tokens", impact: 40 },
      { asset: "Stablecoins", impact: 5 },
    ]
  },
};

// Asset category mapping
const ASSET_CATEGORIES: Record<string, string> = {
  "ETH": "Ethereum",
  "BTC": "Bitcoin",
  "USDC": "Stablecoins",
  "USDT": "Stablecoins",
  "DAI": "Stablecoins",
  "AAVE": "DeFi tokens",
  "UNI": "DeFi tokens",
  "COMP": "DeFi tokens",
  "LINK": "DeFi tokens",
  "SNX": "DeFi tokens",
  "MKR": "DeFi tokens",
  "YFI": "DeFi tokens",
  "SUSHI": "DeFi tokens",
  "CRV": "DeFi tokens",
};

export default function MarketScenarioSimulator() {
  const { assets, portfolioValue } = usePortfolio();
  const [selectedScenario, setSelectedScenario] = useState<keyof typeof SCENARIO_DESCRIPTIONS | null>(null);
  const [severity, setSeverity] = useState(100); // 0-100 severity of the scenario
  // Define a proper type for simulation results
  type SimulationResults = {
    impactedAssets: Array<{
      id: string;
      name: string;
      symbol: string;
      value: number;
      originalValue: number;
      newValue: number;
      change: number;
    }>;
    originalValue: number;
    newValue: number;
    percentChange: number;
    timeSeriesData: Array<{month: string; value: number}>;
    scenario: keyof typeof SCENARIO_DESCRIPTIONS;
  };
  
  const [simulationResults, setSimulationResults] = useState<SimulationResults | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  
  // Determine which category an asset belongs to
  const getAssetCategory = (assetSymbol: string): string => {
    const symbol = assetSymbol.toUpperCase();
    return ASSET_CATEGORIES[symbol] || "Other";
  };
  
  // Run simulation based on selected scenario and severity
  const runSimulation = () => {
    if (!selectedScenario) return;
    
    setIsSimulating(true);
    
    // Simulation logic
    const scenario = SCENARIO_DESCRIPTIONS[selectedScenario];
    const severityFactor = severity / 100;
    
    // Calculate impact on each asset
    const impactedAssets = assets.map(asset => {
      const category = getAssetCategory(asset.symbol);
      const impactData = scenario.impacts.find(imp => imp.asset === category);
      const impactPercentage = impactData ? impactData.impact * severityFactor : 0;
      const newValue = asset.value * (1 + impactPercentage / 100);
      
      return {
        ...asset,
        originalValue: asset.value,
        newValue: newValue,
        change: impactPercentage
      };
    });
    
    // Calculate overall portfolio impact
    const originalValue = portfolioValue;
    const newValue = impactedAssets.reduce((sum, asset) => sum + asset.newValue, 0);
    const percentChange = ((newValue - originalValue) / originalValue) * 100;
    
    // Generate time series data for chart (simplified simulation)
    const timeSeriesData = generateTimeSeriesData(originalValue, newValue, selectedScenario);
    
    setSimulationResults({
      impactedAssets,
      originalValue,
      newValue,
      percentChange,
      timeSeriesData,
      scenario: selectedScenario
    });
    
    setIsSimulating(false);
  };
  
  // Generate time series data for visualization
  const generateTimeSeriesData = (startValue: number, endValue: number, scenarioKey: keyof typeof SCENARIO_DESCRIPTIONS) => {
    const scenario = SCENARIO_DESCRIPTIONS[scenarioKey];
    const duration = 12; // 12 months simulation
    
    // Different curves for different scenarios
    let curve: string;
    switch (scenarioKey) {
      case 'crypto_winter':
        curve = 'steep-decline';
        break;
      case 'defi_hack':
        curve = 'sharp-drop-recovery';
        break;
      case 'eth_upgrade':
        curve = 'gradual-rise';
        break;
      case 'regulation':
        curve = 'initial-drop-stabilize';
        break;
      case 'institutional':
        curve = 'exponential-rise';
        break;
      default:
        curve = 'linear';
    }
    
    // Generate points based on curve type
    return Array.from({ length: duration + 1 }, (_, i) => {
      const month = i;
      let value: number;
      
      switch (curve) {
        case 'steep-decline':
          // More dramatic drop initially
          value = startValue * (1 - Math.pow(i / duration, 0.5) * (1 - endValue / startValue));
          break;
        case 'sharp-drop-recovery':
          // Quick drop then partial recovery
          if (i < duration * 0.2) {
            // Initial 20% duration: sharp drop to 80% of the total drop
            value = startValue * (1 - (i / (duration * 0.2)) * 0.8 * (1 - endValue / startValue));
          } else {
            // Remaining 80% duration: partial recovery
            const dropFactor = 0.8 * (1 - endValue / startValue);
            const recoveryFactor = dropFactor * 0.3; // Recover 30% of the drop
            value = startValue * (1 - dropFactor + recoveryFactor * ((i - duration * 0.2) / (duration * 0.8)));
          }
          break;
        case 'gradual-rise':
          // Gradual upward curve
          value = startValue + (endValue - startValue) * Math.pow(i / duration, 1.2);
          break;
        case 'initial-drop-stabilize':
          // Quick drop then stabilize
          if (i < duration * 0.3) {
            value = startValue * (1 - (i / (duration * 0.3)) * 0.9 * (1 - endValue / startValue));
          } else {
            value = startValue * (1 - 0.9 * (1 - endValue / startValue)) - 
                   (startValue * (1 - 0.9 * (1 - endValue / startValue)) - endValue) * 
                   ((i - duration * 0.3) / (duration * 0.7));
          }
          break;
        case 'exponential-rise':
          // Accelerating growth
          value = startValue * Math.pow(endValue / startValue, Math.pow(i / duration, 0.8));
          break;
        default:
          // Linear change
          value = startValue + (endValue - startValue) * (i / duration);
      }
      
      // Add some randomness for realism
      const randomFactor = 0.02; // 2% random variation
      const randomness = 1 + (Math.random() * 2 - 1) * randomFactor;
      
      return {
        month: `Month ${month}`,
        value: month === 0 ? startValue : (month === duration ? endValue : value * randomness)
      };
    });
  };
  
  // Reset simulation
  const resetSimulation = () => {
    setSelectedScenario(null);
    setSeverity(100);
    setSimulationResults(null);
  };
  
  // Format currency values
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center">
          <TrendingDown className="mr-2 h-5 w-5 text-primary" />
          Market Scenario Simulator
        </CardTitle>
        <CardDescription>
          Simulate how different market scenarios could affect your portfolio
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!simulationResults ? (
          <>
            <div className="space-y-4">
              <Label>Select Market Scenario:</Label>
              <div className="grid gap-2 md:grid-cols-2 lg:grid-cols-3">
                {Object.entries(SCENARIO_DESCRIPTIONS).map(([key, scenario]) => (
                  <Card 
                    key={key} 
                    className={`cursor-pointer transition-colors ${
                      selectedScenario === key ? 'border-primary' : ''
                    }`}
                    onClick={() => setSelectedScenario(key as keyof typeof SCENARIO_DESCRIPTIONS)}
                  >
                    <CardHeader className="p-3">
                      <CardTitle className="text-sm">{scenario.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 pt-0">
                      <p className="text-xs text-muted-foreground">{scenario.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
            
            {selectedScenario && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Scenario Severity: {severity}%</Label>
                  </div>
                  <Slider
                    value={[severity]}
                    min={10}
                    max={100}
                    step={5}
                    onValueChange={(value) => setSeverity(value[0])}
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Mild</span>
                    <span>Moderate</span>
                    <span>Severe</span>
                  </div>
                </div>
                
                <Alert className="bg-amber-500/10">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    This simulation is for educational purposes only and should not be considered financial advice.
                    Real market events can differ significantly from these scenarios.
                  </AlertDescription>
                </Alert>
                
                <Button className="w-full" onClick={runSimulation}>
                  <Play className="mr-2 h-4 w-4" />
                  Run Simulation
                </Button>
              </div>
            )}
          </>
        ) : (
          <>
            <div className="space-y-4">
              <div className="flex justify-between items-start">
                <div>
                  <h3 className="font-medium text-lg">
                    {SCENARIO_DESCRIPTIONS[simulationResults.scenario as keyof typeof SCENARIO_DESCRIPTIONS].title} - {severity}% Severity
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {SCENARIO_DESCRIPTIONS[simulationResults.scenario as keyof typeof SCENARIO_DESCRIPTIONS].description}
                  </p>
                </div>
                <Button variant="outline" size="sm" onClick={resetSimulation}>
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Reset
                </Button>
              </div>
              
              <div className="rounded-md border p-4 space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm">Current Portfolio Value:</span>
                  <span className="font-medium">{formatCurrency(simulationResults.originalValue)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Simulated Portfolio Value:</span>
                  <span className={`font-medium ${
                    simulationResults.percentChange >= 0 ? 'text-green-500' : 'text-red-500'
                  }`}>
                    {formatCurrency(simulationResults.newValue)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Impact:</span>
                  <span className={`font-medium ${
                    simulationResults.percentChange >= 0 ? 'text-green-500' : 'text-red-500'
                  }`}>
                    {simulationResults.percentChange >= 0 ? '+' : ''}
                    {simulationResults.percentChange.toFixed(2)}%
                  </span>
                </div>
              </div>
              
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={simulationResults.timeSeriesData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                    <XAxis 
                      dataKey="month"
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      tickFormatter={(value) => `$${value/1000}k`}
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={false}
                    />
                    <Tooltip 
                      formatter={(value) => [`$${value.toLocaleString()}`, 'Portfolio Value']}
                      labelFormatter={(label) => `Time: ${label}`}
                    />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="hsl(var(--primary))"
                      strokeWidth={2}
                      dot={{ r: 1 }}
                      activeDot={{ r: 5 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              
              <div>
                <h4 className="font-medium mb-2">Asset Impact Breakdown:</h4>
                <div className="space-y-3">
                  {simulationResults.impactedAssets.map((asset: any) => (
                    <div key={asset.id} className="space-y-1">
                      <div className="flex justify-between">
                        <div className="flex items-center">
                          <div className="h-4 w-4 rounded-full bg-muted flex items-center justify-center mr-2 text-xs">
                            {asset.symbol.substring(0, 1)}
                          </div>
                          <span className="text-sm">{asset.name}</span>
                        </div>
                        <span className={`text-sm font-medium ${
                          asset.change >= 0 ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {asset.change >= 0 ? '+' : ''}
                          {asset.change.toFixed(2)}%
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-secondary rounded-full">
                        <div 
                          className={`h-full rounded-full ${
                            asset.change >= 0 ? 'bg-green-500' : 'bg-red-500'
                          }`}
                          style={{ 
                            width: `${Math.min(100, Math.abs(asset.change))}%`,
                            maxWidth: '100%'
                          }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </CardContent>
      <CardFooter className="border-t pt-4">
        <div className="flex items-start space-x-2 text-xs text-muted-foreground">
          <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <p>
            This AI-powered simulator uses generative models to project how your portfolio might
            perform during various market scenarios. The projections incorporate historical market behavior
            patterns but are not guaranteed to be accurate.
          </p>
        </div>
      </CardFooter>
    </Card>
  );
}