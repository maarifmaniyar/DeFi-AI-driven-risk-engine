import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  FileText, 
  Code, 
  Globe, 
  DollarSign,
  Users,
  Fingerprint,
  Lock
} from "lucide-react";

// MiCA (Markets in Crypto-Assets) and FATF (Financial Action Task Force) compliance rules
const COMPLIANCE_FRAMEWORKS = {
  mica: {
    name: "MiCA Compliance",
    description: "Markets in Crypto-Assets regulation framework from the European Union",
    rules: [
      {
        id: "mica-1",
        title: "Asset-Referenced Token Requirements",
        description: "Requirements for stablecoins and other tokens referenced to other assets",
        status: "active",
        applied: true,
        category: "token_issuance"
      },
      {
        id: "mica-2",
        title: "White Paper Publication",
        description: "Mandatory publication of crypto-asset white papers with specified information",
        status: "active",
        applied: true,
        category: "disclosure"
      },
      {
        id: "mica-3",
        title: "Capital Requirements",
        description: "Reserve and capital requirements for stablecoin issuers",
        status: "active",
        applied: true,
        category: "capital"
      },
      {
        id: "mica-4",
        title: "Authorization Requirements",
        description: "Authorization requirements for crypto-asset service providers",
        status: "active",
        applied: false,
        category: "authorization"
      },
      {
        id: "mica-5",
        title: "Market Abuse Rules",
        description: "Rules to prevent market manipulation and insider trading",
        status: "active",
        applied: true,
        category: "market_integrity"
      }
    ]
  },
  fatf: {
    name: "FATF Guidelines",
    description: "Financial Action Task Force recommendations for virtual assets and service providers",
    rules: [
      {
        id: "fatf-1",
        title: "Travel Rule",
        description: "Requirements for VASPs to exchange customer information for transactions above thresholds",
        status: "active",
        applied: true,
        category: "aml"
      },
      {
        id: "fatf-2",
        title: "KYC/AML Procedures",
        description: "Know Your Customer and Anti-Money Laundering procedures for crypto transactions",
        status: "active",
        applied: true,
        category: "aml"
      },
      {
        id: "fatf-3",
        title: "Risk Assessment",
        description: "Risk-based approach to monitoring virtual asset activities",
        status: "active",
        applied: false,
        category: "risk"
      },
      {
        id: "fatf-4",
        title: "Licensing Requirements",
        description: "Licensing or registration requirements for VASPs",
        status: "active",
        applied: true,
        category: "authorization"
      },
      {
        id: "fatf-5",
        title: "Suspicious Transaction Reporting",
        description: "Requirements to report suspicious transactions to relevant authorities",
        status: "active",
        applied: true,
        category: "reporting"
      }
    ]
  }
};

// Smart contract implementation examples
const SMART_CONTRACT_EXAMPLES: Record<string, string> = {
  "mica-1": `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title MiCA Asset-Referenced Token Compliance
 * @dev Smart contract implementing MiCA compliance for asset-referenced tokens
 */
contract MiCACompliantToken {
    // Reserve requirements
    mapping(address => uint256) private _reserves;
    uint256 private _totalReserves;
    
    // Compliance state
    bool private _compliant = true;
    address private _regulatoryAuthority;
    
    // Events
    event ComplianceStatusChanged(bool status);
    event ReserveUpdated(uint256 newReserve);
    
    constructor(address regulatoryAuthority_) {
        _regulatoryAuthority = regulatoryAuthority_;
    }
    
    // Functions to maintain reserve ratios as per MiCA requirements
    function updateReserves(uint256 amount) external onlyAuthority {
        _totalReserves = amount;
        emit ReserveUpdated(amount);
    }
    
    // Function to update compliance status
    function setComplianceStatus(bool status) external onlyAuthority {
        _compliant = status;
        emit ComplianceStatusChanged(status);
    }
    
    // Check compliance before any token transfer
    function _beforeTokenTransfer() internal view {
        require(_compliant, "Token currently non-compliant with MiCA");
    }
    
    modifier onlyAuthority() {
        require(msg.sender == _regulatoryAuthority, "Caller is not the regulatory authority");
        _;
    }
}`,
  "fatf-1": `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * @title FATF Travel Rule Compliant Transfer
 * @dev Implements FATF Travel Rule for crypto asset transfers
 */
contract TravelRuleCompliance {
    // Threshold in USD for applying travel rule (converted to wei)
    uint256 public travelRuleThreshold = 1000 * 10**18; // Equivalent to $1000
    
    // Structure to hold KYC information
    struct KYCInfo {
        string originatorName;
        string originatorAccount;
        string originatorAddress;
        string beneficiaryName;
        string beneficiaryAccount;
        string beneficiaryAddress;
        bool verified;
    }
    
    // Mapping of transaction hash to KYC information
    mapping(bytes32 => KYCInfo) private _transactionKYC;
    
    // Regulatory authorities with access
    mapping(address => bool) public regulators;
    
    event TransferCompleted(address from, address to, uint256 amount, bytes32 txHash);
    
    constructor() {
        regulators[msg.sender] = true;
    }
    
    // Add KYC information for a transfer above threshold
    function addKYCInfo(
        bytes32 txHash,
        string memory originatorName,
        string memory originatorAccount,
        string memory originatorAddress,
        string memory beneficiaryName,
        string memory beneficiaryAccount,
        string memory beneficiaryAddress
    ) external {
        KYCInfo memory info = KYCInfo({
            originatorName: originatorName,
            originatorAccount: originatorAccount,
            originatorAddress: originatorAddress,
            beneficiaryName: beneficiaryName,
            beneficiaryAccount: beneficiaryAccount,
            beneficiaryAddress: beneficiaryAddress,
            verified: false
        });
        
        _transactionKYC[txHash] = info;
    }
    
    // Verify KYC information (by a regulated entity)
    function verifyKYCInfo(bytes32 txHash) external onlyRegulator {
        require(_transactionKYC[txHash].originatorName.length > 0, "KYC info not found");
        _transactionKYC[txHash].verified = true;
    }
    
    // Execute a compliant transfer
    function transferWithTravelRule(address to, uint256 amount, bytes32 kycHash) external {
        // Check if amount is above threshold
        if (amount >= travelRuleThreshold) {
            // Verify KYC info exists and is verified
            require(_transactionKYC[kycHash].verified, "KYC information not verified");
        }
        
        // Execute transfer logic here
        
        emit TransferCompleted(msg.sender, to, amount, kycHash);
    }
    
    modifier onlyRegulator() {
        require(regulators[msg.sender], "Caller is not a regulator");
        _;
    }
}`
};

interface Rule {
  id: string;
  title: string;
  description: string;
  status: string;
  applied: boolean;
  category: string;
}

interface Framework {
  name: string;
  description: string;
  rules: Rule[];
}

// Component for the rule card
function RuleCard({ rule, framework, onToggle }: { 
  rule: Rule, 
  framework: string,
  onToggle: (id: string, applied: boolean) => void 
}) {
  return (
    <Card className={`mb-4 ${rule.applied ? 'border-green-400/40' : ''}`}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="space-y-1">
            <CardTitle className="text-md">{rule.title}</CardTitle>
            <Badge className={rule.applied ? 'bg-green-600' : 'bg-secondary'}>
              {rule.applied ? 'Applied' : 'Not Applied'}
            </Badge>
          </div>
          <Switch 
            checked={rule.applied} 
            onCheckedChange={(checked) => onToggle(rule.id, checked)}
          />
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className="text-sm text-muted-foreground">{rule.description}</p>
        
        <div className="flex items-center mt-3 text-xs text-muted-foreground">
          <Badge variant="outline" className="mr-2">
            {rule.category.replace('_', ' ')}
          </Badge>
          <span>{framework === 'mica' ? 'MiCA' : 'FATF'} Regulation</span>
        </div>
      </CardContent>
    </Card>
  );
}

export default function ComplianceRules() {
  const [frameworks, setFrameworks] = useState<{
    mica: Framework;
    fatf: Framework;
  }>(COMPLIANCE_FRAMEWORKS);
  const [activeContract, setActiveContract] = useState<string | null>(null);
  
  // Toggle rule application
  const toggleRule = (id: string, applied: boolean) => {
    const updatedFrameworks = { ...frameworks };
    
    // Find and update the rule
    for (const framework of Object.values(updatedFrameworks)) {
      for (let i = 0; i < framework.rules.length; i++) {
        if (framework.rules[i].id === id) {
          framework.rules[i].applied = applied;
          break;
        }
      }
    }
    
    setFrameworks(updatedFrameworks);
  };
  
  // Show smart contract implementation
  const showSmartContract = (id: string) => {
    setActiveContract(id);
  };
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Compliance Rules</h2>
          <p className="text-muted-foreground">
            Implement and manage regulatory compliance using smart contracts
          </p>
        </div>
        <Button>
          <Shield className="mr-2 h-4 w-4" />
          Compliance Report
        </Button>
      </div>
      
      <Alert>
        <AlertTriangle className="h-4 w-4" />
        <AlertDescription>
          Regulatory compliance is crucial for DeFi platforms. Always ensure your implementations meet the latest requirements.
        </AlertDescription>
      </Alert>
      
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="mr-2 h-5 w-5 text-primary" />
              Compliance Frameworks
            </CardTitle>
            <CardDescription>
              Regulatory frameworks and rules applicable to your DeFi activities
            </CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Tabs defaultValue="mica" className="w-full">
              <div className="px-6">
                <TabsList className="w-full">
                  <TabsTrigger value="mica" className="flex-1">MiCA Regulations</TabsTrigger>
                  <TabsTrigger value="fatf" className="flex-1">FATF Guidelines</TabsTrigger>
                </TabsList>
              </div>
              
              <TabsContent value="mica" className="mt-0">
                <ScrollArea className="h-[400px] px-6">
                  <div className="pt-4 pb-6">
                    {frameworks.mica.rules.map(rule => (
                      <RuleCard 
                        key={rule.id} 
                        rule={rule} 
                        framework="mica"
                        onToggle={toggleRule} 
                      />
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
              
              <TabsContent value="fatf" className="mt-0">
                <ScrollArea className="h-[400px] px-6">
                  <div className="pt-4 pb-6">
                    {frameworks.fatf.rules.map(rule => (
                      <RuleCard 
                        key={rule.id} 
                        rule={rule} 
                        framework="fatf"
                        onToggle={toggleRule} 
                      />
                    ))}
                  </div>
                </ScrollArea>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="border-t px-6 py-4">
            <div className="flex justify-between items-center w-full">
              <div className="flex items-center space-x-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span className="text-sm font-medium">7/10 Rules Applied</span>
              </div>
              <Button variant="outline" size="sm">
                <FileText className="mr-2 h-4 w-4" />
                Full Documentation
              </Button>
            </div>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Code className="mr-2 h-5 w-5 text-primary" />
              Smart Contract Implementation
            </CardTitle>
            <CardDescription>
              Smart contract code implementing compliance rules
            </CardDescription>
          </CardHeader>
          <CardContent>
            {activeContract ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="font-medium">
                    {activeContract.startsWith('mica') ? 'MiCA' : 'FATF'} Compliance Implementation
                  </h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setActiveContract(null)}
                  >
                    Back to List
                  </Button>
                </div>
                
                <div className="relative">
                  <pre className="rounded-md bg-muted p-4 overflow-x-auto text-xs">
                    <code className="font-mono">
                      {SMART_CONTRACT_EXAMPLES[activeContract]}
                    </code>
                  </pre>
                  <Button 
                    variant="secondary" 
                    size="sm" 
                    className="absolute top-2 right-2"
                  >
                    Copy
                  </Button>
                </div>
                
                <Alert className="bg-primary/10">
                  <Fingerprint className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    This smart contract is designed to implement {activeContract.startsWith('mica') ? 'MiCA' : 'FATF'} compliance rules
                    directly into your DeFi protocol. Always have it audited before deployment.
                  </AlertDescription>
                </Alert>
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground mb-4">
                  Select a rule to view its smart contract implementation:
                </p>
                
                <div className="space-y-2">
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    onClick={() => showSmartContract('mica-1')}
                  >
                    <DollarSign className="mr-2 h-4 w-4" />
                    MiCA Asset-Referenced Token Implementation
                  </Button>
                  
                  <Button 
                    variant="outline" 
                    className="w-full justify-start" 
                    onClick={() => showSmartContract('fatf-1')}
                  >
                    <Users className="mr-2 h-4 w-4" />
                    FATF Travel Rule Implementation
                  </Button>
                </div>
                
                <div className="rounded-md border p-4 mt-4">
                  <h4 className="font-medium flex items-center mb-2">
                    <Lock className="mr-2 h-4 w-4 text-primary" />
                    Compliance Smart Contract Features
                  </h4>
                  <ul className="text-sm space-y-2 text-muted-foreground">
                    <li>• Automated regulatory checks before transactions</li>
                    <li>• On-chain verification of compliance requirements</li>
                    <li>• Transparent and auditable regulatory adherence</li>
                    <li>• Modular design allowing for regulatory updates</li>
                    <li>• Compatible with major blockchain networks</li>
                  </ul>
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="border-t px-6 py-4">
            <div className="flex justify-between items-center w-full">
              <span className="text-xs text-muted-foreground">
                Last updated: May 14, 2025
              </span>
              <Button size="sm">
                Deploy Contracts
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}