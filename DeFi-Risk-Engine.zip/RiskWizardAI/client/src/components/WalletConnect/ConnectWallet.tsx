import { useState } from "react";
import { Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useWallet } from "@/lib/stores/useWallet";
import { useAudio } from "@/lib/stores/useAudio";

export default function ConnectWallet() {
  const [isOpen, setIsOpen] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const { connect } = useWallet();
  const { playSuccess } = useAudio();
  
  const handleConnect = async () => {
    try {
      setIsConnecting(true);
      await connect();
      playSuccess();
      setIsOpen(false);
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setIsConnecting(false);
    }
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button className="bg-sidebar-primary text-sidebar-primary-foreground hover:bg-sidebar-primary/90">
          <Wallet className="mr-2 h-4 w-4" />
          Connect Wallet
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Connect your wallet</DialogTitle>
          <DialogDescription>
            Connect your wallet to view your DeFi portfolio and risk analysis
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col gap-4 py-4">
          <Button 
            className="flex items-center justify-between w-full p-4" 
            onClick={handleConnect}
            disabled={isConnecting}
          >
            <div className="flex items-center">
              <img 
                src="https://raw.githubusercontent.com/MetaMask/brand-resources/master/SVG/metamask-fox.svg" 
                alt="MetaMask" 
                className="mr-2 h-8 w-8" 
              />
              <div className="text-left">
                <div className="font-medium">MetaMask</div>
                <div className="text-xs text-muted-foreground">Connect to your MetaMask wallet</div>
              </div>
            </div>
            {isConnecting ? (
              <div className="h-5 w-5 animate-spin rounded-full border-2 border-current border-t-transparent"></div>
            ) : (
              <Wallet className="h-5 w-5" />
            )}
          </Button>
          
          <Button className="flex items-center justify-between w-full p-4" variant="outline" disabled>
            <div className="flex items-center">
              <div className="mr-2 h-8 w-8 rounded-full bg-gray-800 flex items-center justify-center">
                <img 
                  src="https://walletconnect.com/walletconnect-logo.svg" 
                  alt="WalletConnect" 
                  className="h-5 w-5" 
                />
              </div>
              <div className="text-left">
                <div className="font-medium">WalletConnect</div>
                <div className="text-xs text-muted-foreground">Connect using WalletConnect</div>
              </div>
            </div>
            <Wallet className="h-5 w-5" />
          </Button>
          
          <Button className="flex items-center justify-between w-full p-4" variant="outline" disabled>
            <div className="flex items-center">
              <div className="mr-2 h-8 w-8 rounded-full bg-blue-700 flex items-center justify-center">
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M8 16C12.4183 16 16 12.4183 16 8C16 3.58172 12.4183 0 8 0C3.58172 0 0 3.58172 0 8C0 12.4183 3.58172 16 8 16Z" fill="white"/>
                  <path d="M8.00002 3L4.66602 8L8.00002 6.5L11.332 8L8.00002 3Z" fill="#0052FF"/>
                  <path d="M8.00002 6.5V10.5L11.334 8L8.00002 6.5Z" fill="#0052FF"/>
                  <path d="M8.00002 10.5V6.5L4.66602 8L8.00002 10.5Z" fill="#0052FF"/>
                  <path d="M8.00002 11L4.66602 8.5L8.00002 13L11.332 8.5L8.00002 11Z" fill="#0052FF"/>
                </svg>
              </div>
              <div className="text-left">
                <div className="font-medium">Coinbase Wallet</div>
                <div className="text-xs text-muted-foreground">Connect using Coinbase Wallet</div>
              </div>
            </div>
            <Wallet className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="flex flex-col space-y-2 text-center text-sm text-muted-foreground">
          <p>
            By connecting your wallet, you agree to our {" "}
            <a href="#" className="underline underline-offset-4 hover:text-primary">
              Terms of Service
            </a>
            {" "} and {" "}
            <a href="#" className="underline underline-offset-4 hover:text-primary">
              Privacy Policy
            </a>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
