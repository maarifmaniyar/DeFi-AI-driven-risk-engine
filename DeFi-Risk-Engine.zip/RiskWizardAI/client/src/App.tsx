import { useEffect, useState } from "react";
import { Router, Route, Switch } from "wouter";
import { Helmet } from "react-helmet-async";
import { useAudio } from "./lib/stores/useAudio";
import Navbar from "./components/Layout/Navbar";
import Sidebar from "./components/Layout/Sidebar";
import Dashboard from "./components/Dashboard/Dashboard";
import PortfolioVisualization from "./components/Visualization/PortfolioVisualization";
import RiskAnalysis from "./pages/RiskAnalysis";
import Assets from "./pages/Assets";
import DefiProtocols from "./pages/DefiProtocols";
import Banking from "./pages/Banking";
import Settings from "./pages/Settings";
import AI from "./pages/AI";
import ComplianceRules from "./components/Compliance/ComplianceRules";
import DigitalIdentityNFT from "./components/Identity/DigitalIdentityNFT";
import Upgrade from "./pages/Upgrade";
import NotFound from "./pages/not-found";

function App() {
  const [loading, setLoading] = useState(true);
  
  // Set up sounds
  useEffect(() => {
    const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio.getState();
    
    // Create background music element
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.2;
    setBackgroundMusic(bgMusic);
    
    // Load effect sounds
    const hitSoundEffect = new Audio("/sounds/hit.mp3");
    setHitSound(hitSoundEffect);
    
    const successSoundEffect = new Audio("/sounds/success.mp3");
    setSuccessSound(successSoundEffect);
    
    // Finish loading
    setLoading(false);
  }, []);
  
  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="flex flex-col items-center">
          <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
          <p className="mt-4 text-lg font-medium text-muted-foreground">Loading DeFi Risk Platform...</p>
        </div>
      </div>
    );
  }
  
  return (
    <Router>
      <Helmet>
        <title>DeFi Risk Advisor | AI-Powered Portfolio Analytics</title>
      </Helmet>
      
      <div className="flex h-screen w-full flex-col md:flex-row">
        <Sidebar />
        
        <main className="flex-1 overflow-auto">
          <Navbar />
          
          <div className="container mx-auto p-4 md:p-6">
            <Switch>
              <Route path="/" component={Dashboard} />
              <Route path="/visualization" component={PortfolioVisualization} />
              <Route path="/risk-analysis" component={RiskAnalysis} />
              <Route path="/assets" component={Assets} />
              <Route path="/defi-protocols" component={DefiProtocols} />
              <Route path="/banking" component={Banking} />
              <Route path="/settings" component={Settings} />
              <Route path="/ai" component={AI} />
              <Route path="/compliance" component={ComplianceRules} />
              <Route path="/identity" component={DigitalIdentityNFT} />
              <Route path="/upgrade" component={Upgrade} />
              <Route component={NotFound} />
            </Switch>
          </div>
        </main>
      </div>
    </Router>
  );
}

export default App;
