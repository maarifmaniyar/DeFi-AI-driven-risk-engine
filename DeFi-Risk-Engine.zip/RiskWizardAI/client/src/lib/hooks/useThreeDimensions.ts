import { useRef, useEffect, useState } from "react";
import * as THREE from "three";
import { useThree } from "@react-three/fiber";

export function useThreeDimensions() {
  const { viewport } = useThree();
  const [dimensions, setDimensions] = useState({
    width: 0,
    height: 0,
    aspect: 1,
  });
  
  useEffect(() => {
    setDimensions({
      width: viewport.width,
      height: viewport.height,
      aspect: viewport.width / viewport.height,
    });
  }, [viewport]);
  
  return dimensions;
}

export function useAnimatedRotation(speed: number = 0.01) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useEffect(() => {
    const interval = setInterval(() => {
      if (meshRef.current) {
        meshRef.current.rotation.y += speed;
      }
    }, 16); // Approximately 60fps
    
    return () => clearInterval(interval);
  }, [speed]);
  
  return meshRef;
}

export function useHover() {
  const [hovered, setHovered] = useState(false);
  
  const bind = {
    onPointerOver: () => setHovered(true),
    onPointerOut: () => setHovered(false),
  };
  
  return [hovered, bind] as const;
}
