import { useState, useEffect } from "react";
import { calculateSharpeRatio, calculateVaR, calculateDiversificationScore } from "../calculations/riskMetrics";

interface Asset {
  name: string;
  value: number;
  historicalPrices?: number[];
  volatility?: number;
}

export function useRiskCalculation(assets: Asset[]) {
  const [riskMetrics, setRiskMetrics] = useState({
    sharpeRatio: 0,
    valueAtRisk: 0,
    diversificationScore: 0,
    riskScore: 0
  });
  
  useEffect(() => {
    if (assets && assets.length > 0) {
      // Calculate risk metrics
      const totalPortfolioValue = assets.reduce((sum, asset) => sum + asset.value, 0);
      
      // For a real app, we would use more complex calculations with real data
      const assetsWithVolatility = assets.map(asset => ({
        ...asset,
        // If we don't have real volatility data, estimate it
        volatility: asset.volatility || (Math.random() * 30 + 10), // Random between 10-40%
        // If we don't have historical prices, generate mock data
        historicalPrices: asset.historicalPrices || generateMockPriceHistory()
      }));
      
      // Calculate Sharpe Ratio (risk-adjusted return)
      const sharpeRatio = calculateSharpeRatio(assetsWithVolatility);
      
      // Calculate Value at Risk
      const valueAtRisk = calculateVaR(assetsWithVolatility, totalPortfolioValue);
      
      // Calculate Diversification Score
      const diversificationScore = calculateDiversificationScore(assetsWithVolatility, totalPortfolioValue);
      
      // Overall risk score (0-100, where higher is more risky)
      const varRiskComponent = Math.min(100, (valueAtRisk / totalPortfolioValue) * 500);
      const sharpeRiskComponent = Math.max(0, 100 - (sharpeRatio * 50));
      const diversificationRiskComponent = 100 - diversificationScore;
      
      const riskScore = Math.round(
        (varRiskComponent * 0.4) + 
        (sharpeRiskComponent * 0.3) + 
        (diversificationRiskComponent * 0.3)
      );
      
      setRiskMetrics({
        sharpeRatio,
        valueAtRisk,
        diversificationScore,
        riskScore: Math.min(100, Math.max(0, riskScore))
      });
    }
  }, [assets]);
  
  return riskMetrics;
}

// Helper to generate mock price history
function generateMockPriceHistory(): number[] {
  const basePrice = Math.random() * 1000 + 100;
  const volatility = Math.random() * 0.1 + 0.05;
  const trend = (Math.random() - 0.5) * 0.01;
  
  return Array(30).fill(0).map((_, i) => {
    const randomWalk = (Math.random() - 0.5) * volatility;
    const trendComponent = trend * i;
    return basePrice * (1 + randomWalk + trendComponent);
  });
}
