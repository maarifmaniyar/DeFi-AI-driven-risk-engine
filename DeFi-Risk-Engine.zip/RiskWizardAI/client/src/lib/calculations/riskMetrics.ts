interface Asset {
  name: string;
  value: number;
  historicalPrices?: number[];
  volatility?: number;
}

// Calculate Sharpe Ratio (risk-adjusted return)
export function calculateSharpeRatio(assets: Asset[]): number {
  // In a real app, we would calculate this using real historical returns
  // For this demo, we'll use a simplified approach
  
  // Assume a risk-free rate of 2%
  const riskFreeRate = 0.02;
  
  // Calculate weighted portfolio return
  let totalValue = assets.reduce((sum, asset) => sum + asset.value, 0);
  
  // Mock portfolio return (in a real app, this would be calculated from historical data)
  const portfolioReturn = 0.08; // 8% annual return
  
  // Calculate weighted portfolio volatility (standard deviation)
  const weightedVolatility = assets.reduce((sum, asset) => {
    const weight = asset.value / totalValue;
    return sum + weight * (asset.volatility || 20) / 100;
  }, 0);
  
  // Sharpe Ratio = (Portfolio Return - Risk Free Rate) / Portfolio Volatility
  const sharpeRatio = (portfolioReturn - riskFreeRate) / weightedVolatility;
  
  return Number(sharpeRatio.toFixed(2));
}

// Calculate Value at Risk (VaR)
export function calculateVaR(assets: Asset[], totalValue: number): number {
  // In a real app, we would use historical simulation, variance-covariance, or Monte Carlo methods
  // For this demo, we'll use a simplified approach
  
  // Confidence level (95%)
  const confidenceLevel = 0.95;
  const zScore = 1.645; // Z-score for 95% confidence
  
  // Calculate weighted portfolio volatility
  const weightedVolatility = assets.reduce((sum, asset) => {
    const weight = asset.value / totalValue;
    return sum + weight * (asset.volatility || 20) / 100;
  }, 0);
  
  // Daily VaR = Portfolio Value * Z-Score * Daily Volatility
  // Assume daily volatility is annual volatility / sqrt(252)
  const dailyVolatility = weightedVolatility / Math.sqrt(252);
  const var95 = totalValue * zScore * dailyVolatility;
  
  return Number(var95.toFixed(2));
}

// Calculate Diversification Score
export function calculateDiversificationScore(assets: Asset[], totalValue: number): number {
  // A simple diversification score based on portfolio concentration
  
  // Calculate Herfindahl-Hirschman Index (HHI)
  const hhi = assets.reduce((sum, asset) => {
    const weight = asset.value / totalValue;
    return sum + Math.pow(weight, 2);
  }, 0);
  
  // Convert HHI to a score between 0-100
  // HHI of 1 means complete concentration (single asset)
  // HHI approaches 0 as diversification increases
  const score = (1 - hhi) * 100;
  
  return Math.round(score);
}

// Calculate Beta (market correlation)
export function calculateBeta(assetReturns: number[], marketReturns: number[]): number {
  // Beta = Covariance(Asset, Market) / Variance(Market)
  
  if (assetReturns.length !== marketReturns.length || assetReturns.length === 0) {
    return 1; // Default to market beta if no data
  }
  
  // Calculate average returns
  const avgAssetReturn = assetReturns.reduce((sum, val) => sum + val, 0) / assetReturns.length;
  const avgMarketReturn = marketReturns.reduce((sum, val) => sum + val, 0) / marketReturns.length;
  
  // Calculate covariance and market variance
  let covariance = 0;
  let marketVariance = 0;
  
  for (let i = 0; i < assetReturns.length; i++) {
    covariance += (assetReturns[i] - avgAssetReturn) * (marketReturns[i] - avgMarketReturn);
    marketVariance += Math.pow(marketReturns[i] - avgMarketReturn, 2);
  }
  
  covariance /= assetReturns.length;
  marketVariance /= marketReturns.length;
  
  return Number((covariance / marketVariance).toFixed(2));
}

// Calculate portfolio risk score (0-100, higher means more risky)
export function calculateRiskScore(
  sharpeRatio: number,
  diversificationScore: number,
  volatility: number,
  smartContractRisk: number
): number {
  // Normalize inputs
  const sharpeComponent = Math.max(0, 100 - (sharpeRatio * 50)); // Lower sharpe = higher risk
  const diversificationComponent = 100 - diversificationScore; // Lower diversification = higher risk
  const volatilityComponent = Math.min(100, volatility * 200); // Higher volatility = higher risk
  const smartContractComponent = smartContractRisk; // 0-100 scale
  
  // Weighted sum
  const riskScore = 
    (sharpeComponent * 0.25) + 
    (diversificationComponent * 0.25) + 
    (volatilityComponent * 0.3) + 
    (smartContractComponent * 0.2);
  
  return Math.min(100, Math.max(0, Math.round(riskScore)));
}
