import { create } from "zustand";
import { connectMetamask, disconnectWallet } from "../web3/metamask";

interface WalletState {
  isConnected: boolean;
  address: string;
  chainId: number | null;
  balance: string;
  
  connect: () => Promise<void>;
  disconnect: () => void;
  updateBalance: (newBalance: string) => void;
}

export const useWallet = create<WalletState>((set) => ({
  isConnected: false,
  address: "",
  chainId: null,
  balance: "0",
  
  connect: async () => {
    try {
      const walletInfo = await connectMetamask();
      
      if (walletInfo) {
        set({
          isConnected: true,
          address: walletInfo.address,
          chainId: walletInfo.chainId,
          balance: walletInfo.balance
        });
      }
    } catch (error) {
      console.error("Failed to connect wallet:", error);
      throw error;
    }
  },
  
  disconnect: () => {
    disconnectWallet();
    set({
      isConnected: false,
      address: "",
      chainId: null,
      balance: "0"
    });
  },
  
  updateBalance: (newBalance: string) => {
    set({ balance: newBalance });
  }
}));
