import { create } from "zustand";
import { apiRequest } from "../queryClient";

export interface Asset {
  id: number;
  name: string;
  symbol: string;
  value: number;
  change: number;
  quantity: number;
  price: number;
}

export interface AssetAllocation {
  id: number;
  name: string;
  value: number;
  percentage: number;
}

export interface AssetByChain {
  id: number;
  name: string;
  value: number;
  percentage: number;
  chainId: number;
}

export interface AssetType {
  id: number;
  name: string;
  value: number;
  percentage: number;
  riskLevel: string;
}

interface PortfolioHistory {
  date: string;
  value: number;
}

interface PortfolioState {
  // Portfolio data
  portfolioValue: number;
  portfolioChange: number;
  portfolioHistory: PortfolioHistory[];
  assets: Asset[];
  assetAllocation: AssetAllocation[];
  assetsByChain: AssetByChain[];
  assetTypes: AssetType[];
  riskScore: number;
  
  // Loading state
  loading: boolean;
  
  // Actions
  loadPortfolioData: () => Promise<void>;
}

// Generate a date for the past N days
const getPastDate = (daysAgo: number): string => {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  return date.toISOString().split('T')[0];
};

export const usePortfolio = create<PortfolioState>((set, get) => ({
  // Initial data
  portfolioValue: 152467.83,
  portfolioChange: 3.28,
  portfolioHistory: Array.from({ length: 30 }, (_, i) => ({
    date: getPastDate(29 - i),
    value: 140000 + Math.random() * 20000 + i * 500
  })),
  assets: [
    { id: 1, name: "Ethereum", symbol: "ETH", value: 58432.50, change: 5.2, quantity: 24.5, price: 2384.59 },
    { id: 2, name: "Bitcoin", symbol: "BTC", value: 42125.75, change: 2.8, quantity: 0.78, price: 54007.37 },
    { id: 3, name: "USD Coin", symbol: "USDC", value: 25000, change: 0, quantity: 25000, price: 1 },
    { id: 4, name: "Aave", symbol: "AAVE", value: 12500.33, change: -1.2, quantity: 120, price: 104.17 },
    { id: 5, name: "Uniswap", symbol: "UNI", value: 8240.15, change: -2.4, quantity: 1500, price: 5.49 },
    { id: 6, name: "Compound", symbol: "COMP", value: 6169.10, change: 1.7, quantity: 150, price: 41.13 }
  ],
  assetAllocation: [
    { id: 1, name: "Ethereum", value: 58432.50, percentage: 38.32 },
    { id: 2, name: "Bitcoin", value: 42125.75, percentage: 27.63 },
    { id: 3, name: "Stablecoins", value: 25000, percentage: 16.40 },
    { id: 4, name: "DeFi Tokens", value: 26909.58, percentage: 17.65 }
  ],
  assetsByChain: [
    { id: 1, name: "Ethereum", value: 102242.08, percentage: 67.06, chainId: 1 },
    { id: 2, name: "Polygon", value: 18376.42, percentage: 12.05, chainId: 137 },
    { id: 3, name: "Avalanche", value: 10234.76, percentage: 6.71, chainId: 43114 },
    { id: 4, name: "Arbitrum", value: 12478.25, percentage: 8.18, chainId: 42161 },
    { id: 5, name: "Optimism", value: 9136.32, percentage: 5.99, chainId: 10 }
  ],
  assetTypes: [
    { id: 1, name: "Layer 1 Tokens", value: 100558.25, percentage: 65.95, riskLevel: "Medium" },
    { id: 2, name: "Stablecoins", value: 25000, percentage: 16.40, riskLevel: "Low" },
    { id: 3, name: "Lending Protocol Tokens", value: 18669.43, percentage: 12.24, riskLevel: "High" },
    { id: 4, name: "DEX Tokens", value: 8240.15, percentage: 5.41, riskLevel: "High" }
  ],
  riskScore: 57,
  
  // Loading state
  loading: false,
  
  // Actions
  loadPortfolioData: async () => {
    try {
      set({ loading: true });
      
      // In a real app, we would fetch data from the backend
      // For this demo, we're using mock data that's already set in the initial state
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // We'll just keep using our initial data, but in a real app we would do something like:
      // const response = await apiRequest("GET", "/api/portfolio", undefined);
      // const data = await response.json();
      // set({ ...data, loading: false });
      
      set({ loading: false });
    } catch (error) {
      console.error("Error loading portfolio data:", error);
      set({ loading: false });
    }
  }
}));
