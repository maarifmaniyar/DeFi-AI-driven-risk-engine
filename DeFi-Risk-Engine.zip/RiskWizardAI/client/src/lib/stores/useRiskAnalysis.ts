import { create } from "zustand";
import { apiRequest } from "../queryClient";

interface RiskMetric {
  id: number;
  name: string;
  value: string;
  description: string;
  status: 'good' | 'warning' | 'danger';
  interpretation: string;
}

interface VolatilityData {
  id: number;
  name: string;
  symbol: string;
  volatility: number;
}

interface SmartContractRisk {
  id: number;
  name: string;
  riskLevel: 'High' | 'Medium' | 'Low';
  exposure: number;
}

interface MarketTrend {
  id: number;
  name: string;
  color: string;
  data: Array<{ date: string, value: number }>;
}

interface MarketAlert {
  id: number;
  title: string;
  description: string;
  severity: 'high' | 'medium' | 'low';
  type: 'positive' | 'negative' | 'neutral';
}

interface CorrelatedAsset {
  id: number;
  pair: string;
  correlation: number;
  implication: string;
}

interface ProtocolRisk {
  id: number;
  name: string;
  riskScore: number;
  exposure: number;
}

interface RiskAnalysisState {
  riskMetrics: RiskMetric[];
  volatilityByAsset: VolatilityData[];
  smartContractRisks: SmartContractRisk[];
  marketTrends: MarketTrend[];
  marketAlerts: MarketAlert[];
  correlatedAssets: CorrelatedAsset[];
  protocolRiskMap: ProtocolRisk[];
  
  loading: boolean;
  loadRiskData: () => Promise<void>;
}

// Generate date for past N days
const getPastDate = (daysAgo: number): string => {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  return date.toISOString().split('T')[0];
};

// Generate market trend data with some randomness but following a trend
const generateTrendData = (startValue: number, volatility: number, trend: number) => {
  return Array.from({ length: 30 }, (_, i) => {
    const randomFactor = (Math.random() - 0.5) * volatility;
    const trendFactor = trend * i / 30;
    let value = startValue * (1 + randomFactor + trendFactor);
    value = Math.max(value, startValue * 0.5); // Ensure value doesn't go too low
    return {
      date: getPastDate(29 - i),
      value
    };
  });
};

export const useRiskAnalysis = create<RiskAnalysisState>((set) => ({
  riskMetrics: [
    {
      id: 1,
      name: "VaR (95%)",
      value: "$12,742",
      description: "Value at Risk - maximum potential loss with 95% confidence over next 24 hours",
      status: "warning",
      interpretation: "Moderate Risk"
    },
    {
      id: 2,
      name: "Sharpe Ratio",
      value: "1.23",
      description: "Measure of risk-adjusted return (higher is better)",
      status: "warning",
      interpretation: "Average"
    },
    {
      id: 3,
      name: "Beta",
      value: "1.42",
      description: "Volatility compared to overall crypto market",
      status: "danger",
      interpretation: "High Volatility"
    },
    {
      id: 4,
      name: "Diversification",
      value: "68/100",
      description: "How well your assets are diversified to reduce risk",
      status: "warning",
      interpretation: "Moderate"
    },
    {
      id: 5,
      name: "Impermanent Loss Risk",
      value: "High",
      description: "Risk of loss from providing liquidity to AMMs",
      status: "danger",
      interpretation: "Significant Exposure"
    },
    {
      id: 6,
      name: "Liquidity Risk",
      value: "Medium",
      description: "Risk of being unable to exit positions quickly",
      status: "warning",
      interpretation: "Manageable"
    }
  ],
  volatilityByAsset: [
    { id: 1, name: "Bitcoin", symbol: "BTC", volatility: 42.6 },
    { id: 2, name: "Ethereum", symbol: "ETH", volatility: 56.8 },
    { id: 3, name: "USD Coin", symbol: "USDC", volatility: 0.4 },
    { id: 4, name: "Aave", symbol: "AAVE", volatility: 87.3 },
    { id: 5, name: "Uniswap", symbol: "UNI", volatility: 92.1 },
    { id: 6, name: "Compound", symbol: "COMP", volatility: 78.6 }
  ],
  smartContractRisks: [
    { id: 1, name: "Uniswap V3", riskLevel: "Low", exposure: 8240.15 },
    { id: 2, name: "Aave V2", riskLevel: "Low", exposure: 12500.33 },
    { id: 3, name: "Compound V2", riskLevel: "Medium", exposure: 6169.10 },
    { id: 4, name: "SushiSwap", riskLevel: "Medium", exposure: 2450.75 },
    { id: 5, name: "Curve Finance", riskLevel: "Low", exposure: 3270.45 },
    { id: 6, name: "Balancer V2", riskLevel: "Medium", exposure: 1840.32 },
    { id: 7, name: "Yearn Finance", riskLevel: "High", exposure: 1640.87 }
  ],
  marketTrends: [
    {
      id: 1,
      name: "Bitcoin",
      color: "#F7931A",
      data: generateTrendData(50000, 0.10, 0.05)
    },
    {
      id: 2,
      name: "Ethereum",
      color: "#627EEA",
      data: generateTrendData(2500, 0.15, 0.08)
    },
    {
      id: 3,
      name: "DeFi Index",
      color: "#2775CA",
      data: generateTrendData(10000, 0.20, -0.02)
    }
  ],
  marketAlerts: [
    {
      id: 1,
      title: "Bitcoin ETF approval expected within weeks",
      description: "SEC signals possible approval of spot Bitcoin ETF applications, potentially increasing institutional adoption.",
      severity: "medium",
      type: "positive"
    },
    {
      id: 2,
      title: "High gas fees on Ethereum network",
      description: "Unusually high network congestion is causing elevated transaction costs, impacting DeFi interactions.",
      severity: "medium",
      type: "negative"
    },
    {
      id: 3,
      title: "Regulatory concerns for DeFi lending platforms",
      description: "New regulations being discussed may impact lending protocols in your portfolio.",
      severity: "high",
      type: "negative"
    }
  ],
  correlatedAssets: [
    {
      id: 1,
      pair: "ETH / AAVE",
      correlation: 0.87,
      implication: "High correlation increases portfolio risk during market downturns"
    },
    {
      id: 2,
      pair: "BTC / ETH",
      correlation: 0.82,
      implication: "Strong correlation between major assets reduces diversification benefits"
    },
    {
      id: 3,
      pair: "USDC / ETH",
      correlation: -0.12,
      implication: "Negative correlation provides hedging benefits during volatility"
    },
    {
      id: 4,
      pair: "UNI / COMP",
      correlation: 0.91,
      implication: "Very high correlation between DeFi governance tokens"
    }
  ],
  protocolRiskMap: [
    { id: 1, name: "Uniswap", riskScore: 28, exposure: 8240 },
    { id: 2, name: "Aave", riskScore: 42, exposure: 12500 },
    { id: 3, name: "Compound", riskScore: 51, exposure: 6169 },
    { id: 4, name: "Curve", riskScore: 32, exposure: 3270 },
    { id: 5, name: "Yearn", riskScore: 68, exposure: 1641 },
    { id: 6, name: "SushiSwap", riskScore: 55, exposure: 2451 },
    { id: 7, name: "Balancer", riskScore: 47, exposure: 1840 },
    { id: 8, name: "MakerDAO", riskScore: 31, exposure: 2700 },
    { id: 9, name: "Synthetix", riskScore: 72, exposure: 1100 },
    { id: 10, name: "Lido", riskScore: 45, exposure: 4800 },
    { id: 11, name: "dYdX", riskScore: 62, exposure: 1500 },
    { id: 12, name: "Bancor", riskScore: 58, exposure: 900 }
  ],
  
  loading: false,
  
  loadRiskData: async () => {
    try {
      set({ loading: true });
      
      // In a real app, we would fetch data from the backend
      // For this demo, we're using mock data that's already set in the initial state
      
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // We'll just keep using our initial data
      set({ loading: false });
    } catch (error) {
      console.error("Error loading risk data:", error);
      set({ loading: false });
    }
  }
}));
