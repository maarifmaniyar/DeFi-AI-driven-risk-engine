// Check if MetaMask is installed
export const isMetaMaskInstalled = (): boolean => {
  return typeof window !== "undefined" && 
         window.ethereum !== undefined && 
         window.ethereum.isMetaMask === true;
};

interface WalletInfo {
  address: string;
  chainId: number;
  balance: string;
}

// Connect to MetaMask
export const connectMetamask = async (): Promise<WalletInfo | null> => {
  // In our demo environment, we'll use mock data if MetaMask is not installed
  if (!isMetaMaskInstalled()) {
    console.log("MetaMask not detected - using demo mode with mock data");
    
    // Return mock wallet info for demo purposes
    return {
      address: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
      chainId: 1, // Ethereum Mainnet
      balance: "2.5432"
    };
  }
  
  try {
    // Request accounts
    const accounts = await window.ethereum.request({ 
      method: "eth_requestAccounts" 
    });
    
    if (accounts.length === 0) {
      throw new Error("No accounts found - user may have denied access");
    }
    
    const address = accounts[0];
    
    // Get chain ID
    const chainId = await window.ethereum.request({ 
      method: "eth_chainId" 
    });
    
    // Get balance
    const balance = await window.ethereum.request({ 
      method: "eth_getBalance",
      params: [address, "latest"]
    });
    
    const ethBalance = parseInt(balance, 16) / (10 ** 18);
    
    // Subscribe to account change events
    window.ethereum.on("accountsChanged", handleAccountsChanged);
    window.ethereum.on("chainChanged", handleChainChanged);
    
    return {
      address,
      chainId: parseInt(chainId, 16),
      balance: ethBalance.toFixed(4)
    };
  } catch (error) {
    console.error("Error connecting to MetaMask:", error);
    throw error;
  }
};

// Disconnect from MetaMask
export const disconnectWallet = (): void => {
  if (typeof window !== "undefined" && window.ethereum) {
    // Remove event listeners
    window.ethereum.removeListener("accountsChanged", handleAccountsChanged);
    window.ethereum.removeListener("chainChanged", handleChainChanged);
  }
};

// Handler for accounts changed
const handleAccountsChanged = (accounts: string[]): void => {
  // Reload the page to reset the app state
  window.location.reload();
};

// Handler for chain changed
const handleChainChanged = (): void => {
  // Reload the page to reset the app state
  window.location.reload();
};

// Get ethereum object type
declare global {
  interface Window {
    ethereum: any;
  }
}
