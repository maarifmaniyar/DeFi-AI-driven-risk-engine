declare module 'react-speech-recognition' {
  interface SpeechRecognitionOptions {
    continuous?: boolean;
    interimResults?: boolean;
  }

  interface SpeechRecognitionListenOptions {
    continuous?: boolean;
    language?: string;
    interimResults?: boolean;
  }

  interface SpeechRecognition {
    startListening: (options?: SpeechRecognitionListenOptions) => void;
    stopListening: () => void;
    abortListening: () => void;
    browserSupportsSpeechRecognition: boolean;
  }

  interface UseSpeechRecognitionResult {
    transcript: string;
    listening: boolean;
    interimTranscript: string;
    finalTranscript: string;
    resetTranscript: () => void;
    browserSupportsSpeechRecognition: boolean;
  }

  function useSpeechRecognition(options?: SpeechRecognitionOptions): UseSpeechRecognitionResult;
  const SpeechRecognition: SpeechRecognition;

  export { useSpeechRecognition };
  export default SpeechRecognition;
}