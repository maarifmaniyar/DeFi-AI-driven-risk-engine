import { useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useRiskAnalysis } from "@/lib/stores/useRiskAnalysis";
import { Shield, AlertTriangle, CheckCircle } from "lucide-react";

export default function DefiProtocols() {
  const { loadRiskData, protocolRiskMap, smartContractRisks } = useRiskAnalysis();
  
  useEffect(() => {
    loadRiskData();
  }, [loadRiskData]);
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">DeFi Protocols</h2>
        <p className="text-muted-foreground">
          Analyze the security and risk of DeFi protocols in your portfolio
        </p>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Protocol Security Overview</CardTitle>
          <CardDescription>
            Risk assessment and security status of your DeFi protocols
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Protocol</TableHead>
                <TableHead>Risk Score</TableHead>
                <TableHead>Exposure</TableHead>
                <TableHead>Security Status</TableHead>
                <TableHead>Recommendation</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {protocolRiskMap.map((protocol) => (
                <TableRow key={protocol.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 mr-2 text-primary" />
                      <div>{protocol.name}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="mr-2 h-2.5 w-2.5 rounded-full bg-secondary">
                        <div 
                          className="h-full w-full rounded-full" 
                          style={{ 
                            background: protocol.riskScore < 30 ? '#10b981' : 
                              protocol.riskScore < 70 ? '#f59e0b' : '#ef4444'
                          }}
                        ></div>
                      </div>
                      <span>{protocol.riskScore}/100</span>
                    </div>
                  </TableCell>
                  <TableCell>${protocol.exposure.toLocaleString()}</TableCell>
                  <TableCell>
                    {protocol.riskScore < 30 ? (
                      <Badge className="bg-green-500">Safe</Badge>
                    ) : protocol.riskScore < 70 ? (
                      <Badge className="bg-yellow-500">Moderate Risk</Badge>
                    ) : (
                      <Badge className="bg-red-500">High Risk</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {protocol.riskScore < 30 ? (
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                        <span>Low risk, suitable for investment</span>
                      </div>
                    ) : protocol.riskScore < 70 ? (
                      <div className="flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-1 text-yellow-500" />
                        <span>Moderate risk, limit exposure</span>
                      </div>
                    ) : (
                      <div className="flex items-center">
                        <AlertTriangle className="h-4 w-4 mr-1 text-red-500" />
                        <span>High risk, consider reducing exposure</span>
                      </div>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Top Secure Protocols</CardTitle>
            <CardDescription>
              DeFi protocols with the best security ratings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {protocolRiskMap
                .filter(p => p.riskScore < 40)
                .sort((a, b) => a.riskScore - b.riskScore)
                .slice(0, 5)
                .map((protocol) => (
                  <div key={protocol.id} className="flex justify-between items-center border-b pb-2 last:border-0">
                    <div className="flex items-center">
                      <Shield className="h-5 w-5 mr-2 text-green-500" />
                      <span className="font-medium">{protocol.name}</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-green-500 font-medium">{protocol.riskScore}/100</span>
                    </div>
                  </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Protocols to Watch</CardTitle>
            <CardDescription>
              High risk protocols requiring attention
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {protocolRiskMap
                .filter(p => p.riskScore >= 60)
                .sort((a, b) => b.riskScore - a.riskScore)
                .slice(0, 5)
                .map((protocol) => (
                  <div key={protocol.id} className="flex justify-between items-center border-b pb-2 last:border-0">
                    <div className="flex items-center">
                      <AlertTriangle className="h-5 w-5 mr-2 text-red-500" />
                      <span className="font-medium">{protocol.name}</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-red-500 font-medium">{protocol.riskScore}/100</span>
                    </div>
                  </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}