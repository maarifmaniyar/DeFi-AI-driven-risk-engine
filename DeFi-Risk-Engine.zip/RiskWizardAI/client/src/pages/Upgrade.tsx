import { useState } from "react";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowRight, 
  Check, 
  Star, 
  Shield, 
  BarChart3, 
  Sparkles, 
  Zap, 
  Cpu, 
  Lock, 
  CreditCard
} from "lucide-react";

// Pricing tiers definition
const PRICING_TIERS = [
  {
    id: "basic",
    name: "Basic",
    price: 0,
    description: "Essential DeFi risk monitoring",
    features: [
      "Basic portfolio tracking",
      "Simple risk assessment",
      "Standard data visualizations",
      "Daily portfolio updates",
      "Single wallet connection",
    ],
    limitations: [
      "No AI-powered features",
      "Limited historical data (30 days)",
      "No cross-chain analysis",
      "No compliance tools"
    ],
    cta: "Current Plan",
    recommended: false,
    disabled: true
  },
  {
    id: "pro",
    name: "Pro",
    price: 29,
    description: "Advanced risk analysis for serious investors",
    features: [
      "All Basic features",
      "AI market scenario simulator",
      "Voice assistant integration",
      "Multi-wallet support",
      "Advanced portfolio analytics",
      "Risk alerts and notifications",
      "90-day historical data",
      "Priority customer support"
    ],
    limitations: [],
    cta: "Upgrade Now",
    recommended: true,
    disabled: false
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: 99,
    description: "Institutional-grade risk management",
    features: [
      "All Pro features",
      "Compliance rules engine",
      "Digital identity NFT integration",
      "Unlimited historical data",
      "Custom risk models",
      "API access",
      "White-glove onboarding",
      "Dedicated account manager",
      "Custom integrations",
      "Multi-user access"
    ],
    limitations: [],
    cta: "Contact Sales",
    recommended: false,
    disabled: false
  }
];

// Feature comparison table data
const FEATURE_COMPARISON = [
  {
    category: "Portfolio Analysis",
    features: [
      {
        name: "Portfolio Tracking",
        basic: true,
        pro: true,
        enterprise: true
      },
      {
        name: "Multi-wallet Support",
        basic: false,
        pro: true,
        enterprise: true
      },
      {
        name: "Cross-chain Analysis",
        basic: false,
        pro: true,
        enterprise: true
      },
      {
        name: "Historical Data",
        basic: "30 days",
        pro: "90 days",
        enterprise: "Unlimited"
      }
    ]
  },
  {
    category: "Risk Assessment",
    features: [
      {
        name: "Basic Risk Metrics",
        basic: true,
        pro: true,
        enterprise: true
      },
      {
        name: "Advanced Risk Models",
        basic: false,
        pro: true,
        enterprise: true
      },
      {
        name: "Custom Risk Scenarios",
        basic: false,
        pro: false,
        enterprise: true
      },
      {
        name: "Risk Alerts",
        basic: false,
        pro: true,
        enterprise: true
      }
    ]
  },
  {
    category: "AI Features",
    features: [
      {
        name: "Voice Assistant",
        basic: false,
        pro: true,
        enterprise: true
      },
      {
        name: "Market Scenario Simulation",
        basic: false,
        pro: true,
        enterprise: true
      },
      {
        name: "Predictive Analytics",
        basic: false,
        pro: false,
        enterprise: true
      }
    ]
  },
  {
    category: "Compliance & Identity",
    features: [
      {
        name: "Compliance Rules Engine",
        basic: false,
        pro: false,
        enterprise: true
      },
      {
        name: "Digital Identity NFTs",
        basic: false,
        pro: false,
        enterprise: true
      },
      {
        name: "Regulatory Reporting",
        basic: false,
        pro: false,
        enterprise: true
      }
    ]
  },
  {
    category: "Support",
    features: [
      {
        name: "Customer Support",
        basic: "Email",
        pro: "Priority Email",
        enterprise: "Dedicated Manager"
      },
      {
        name: "Update Frequency",
        basic: "Monthly",
        pro: "Weekly",
        enterprise: "Weekly + Custom"
      }
    ]
  }
];

// Billing cycle options
const BILLING_CYCLES = [
  { id: "monthly", name: "Monthly", multiplier: 1 },
  { id: "annual", name: "Annual", multiplier: 0.8, discount: "20%" }
];

export default function Upgrade() {
  const [selectedTier, setSelectedTier] = useState<string>("pro");
  const [billingCycle, setBillingCycle] = useState<string>("monthly");
  
  // Handle tier selection
  const handleTierSelect = (tierId: string) => {
    setSelectedTier(tierId);
  };
  
  // Get pricing with potential discount
  const getAdjustedPrice = (basePrice: number) => {
    const cycle = BILLING_CYCLES.find(c => c.id === billingCycle);
    return basePrice * (cycle?.multiplier || 1);
  };
  
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Upgrade Your Plan</h2>
        <p className="text-muted-foreground">
          Unlock advanced features and comprehensive risk analysis tools
        </p>
      </div>
      
      {/* Billing cycle selector */}
      <Card className="bg-muted/30">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div>
              <h3 className="font-medium">Choose Billing Cycle</h3>
              <p className="text-sm text-muted-foreground">
                Save with annual billing
              </p>
            </div>
            <Tabs 
              defaultValue={billingCycle} 
              onValueChange={setBillingCycle}
              className="w-full sm:w-auto"
            >
              <TabsList className="grid w-full grid-cols-2">
                {BILLING_CYCLES.map(cycle => (
                  <TabsTrigger 
                    key={cycle.id} 
                    value={cycle.id}
                    className="relative"
                  >
                    {cycle.name}
                    {cycle.discount && (
                      <Badge 
                        className="absolute -top-2 -right-2 text-[10px] bg-green-600 hover:bg-green-600"
                      >
                        Save {cycle.discount}
                      </Badge>
                    )}
                  </TabsTrigger>
                ))}
              </TabsList>
            </Tabs>
          </div>
        </CardContent>
      </Card>
      
      {/* Pricing cards */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {PRICING_TIERS.map((tier) => {
          const isSelected = selectedTier === tier.id;
          const adjustedPrice = getAdjustedPrice(tier.price);
          
          return (
            <Card 
              key={tier.id}
              className={`relative border-2 ${
                isSelected ? 'border-primary' : 'border-border'
              } ${tier.recommended ? 'shadow-lg' : ''}`}
            >
              {tier.recommended && (
                <div className="absolute -top-3 left-0 right-0 mx-auto w-fit">
                  <Badge className="bg-primary px-3 py-1">
                    Recommended
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <CardTitle className="flex items-baseline">
                  <span>{tier.name}</span>
                  {tier.id === "basic" && (
                    <Badge variant="outline" className="ml-2">
                      Current
                    </Badge>
                  )}
                </CardTitle>
                <div className="flex items-baseline space-x-1">
                  <span className="text-3xl font-bold">${adjustedPrice}</span>
                  <span className="text-muted-foreground">/mo</span>
                </div>
                <CardDescription>{tier.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {tier.features.map((feature, i) => (
                    <div key={i} className="flex items-start">
                      <Check className="h-4 w-4 mr-2 mt-1 text-green-500" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
                
                {tier.limitations.length > 0 && (
                  <div className="pt-2 space-y-2">
                    {tier.limitations.map((limitation, i) => (
                      <div key={i} className="flex items-start">
                        <span className="h-4 w-4 mr-2 mt-1 text-muted-foreground">-</span>
                        <span className="text-sm text-muted-foreground">{limitation}</span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button 
                  className="w-full"
                  variant={isSelected ? "default" : "outline"}
                  onClick={() => handleTierSelect(tier.id)}
                  disabled={tier.disabled}
                >
                  {isSelected ? (
                    <Check className="mr-2 h-4 w-4" />
                  ) : (
                    <ArrowRight className="mr-2 h-4 w-4" />
                  )}
                  {tier.cta}
                </Button>
              </CardFooter>
            </Card>
          );
        })}
      </div>
      
      {/* Feature comparison */}
      <Card>
        <CardHeader>
          <CardTitle>Feature Comparison</CardTitle>
          <CardDescription>
            Compare features across different plans
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4">Feature</th>
                  <th className="text-center py-3 px-4">Basic</th>
                  <th className="text-center py-3 px-4">Pro</th>
                  <th className="text-center py-3 px-4">Enterprise</th>
                </tr>
              </thead>
              <tbody>
                {FEATURE_COMPARISON.map((category, categoryIndex) => (
                  <>
                    <tr key={`category-${categoryIndex}`} className="bg-muted/30">
                      <td colSpan={4} className="py-2 px-4 font-medium">
                        {category.category}
                      </td>
                    </tr>
                    {category.features.map((feature, featureIndex) => (
                      <tr 
                        key={`feature-${categoryIndex}-${featureIndex}`}
                        className="border-b border-border/40"
                      >
                        <td className="py-3 px-4">{feature.name}</td>
                        <td className="text-center py-3 px-4">
                          {typeof feature.basic === 'boolean' ? (
                            feature.basic ? (
                              <Check className="h-4 w-4 mx-auto text-green-500" />
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )
                          ) : (
                            <span>{feature.basic}</span>
                          )}
                        </td>
                        <td className="text-center py-3 px-4">
                          {typeof feature.pro === 'boolean' ? (
                            feature.pro ? (
                              <Check className="h-4 w-4 mx-auto text-green-500" />
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )
                          ) : (
                            <span>{feature.pro}</span>
                          )}
                        </td>
                        <td className="text-center py-3 px-4">
                          {typeof feature.enterprise === 'boolean' ? (
                            feature.enterprise ? (
                              <Check className="h-4 w-4 mx-auto text-green-500" />
                            ) : (
                              <span className="text-muted-foreground">-</span>
                            )
                          ) : (
                            <span>{feature.enterprise}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
      
      {/* Upgrade benefits */}
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <div className="rounded-full w-10 h-10 flex items-center justify-center bg-primary/10">
              <Shield className="w-5 h-5 text-primary" />
            </div>
            <CardTitle className="mt-2">Enhanced Security</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Gain access to advanced security features and real-time risk alerts to better protect your digital assets.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <div className="rounded-full w-10 h-10 flex items-center justify-center bg-primary/10">
              <BarChart3 className="w-5 h-5 text-primary" />
            </div>
            <CardTitle className="mt-2">Advanced Analytics</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Unlock powerful analytics tools to gain deeper insights into your portfolio performance and market trends.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <div className="rounded-full w-10 h-10 flex items-center justify-center bg-primary/10">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <CardTitle className="mt-2">AI Features</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Benefit from cutting-edge AI capabilities including voice assistant and market scenario simulations.
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <div className="rounded-full w-10 h-10 flex items-center justify-center bg-primary/10">
              <Zap className="w-5 h-5 text-primary" />
            </div>
            <CardTitle className="mt-2">Priority Support</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Get faster responses and dedicated support to help you make the most of your DeFi investments.
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Call to action */}
      <Card className="bg-primary text-primary-foreground">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-2">
              <h3 className="text-xl font-semibold">Ready to upgrade?</h3>
              <p className="text-primary-foreground/80">
                Unlock all features with our Pro plan today. Cancel anytime.
              </p>
            </div>
            <Button 
              variant="secondary"
              size="lg"
              className="whitespace-nowrap"
            >
              <CreditCard className="mr-2 h-4 w-4" />
              {selectedTier === "enterprise" ? "Contact Sales" : "Upgrade Now"}
            </Button>
          </div>
        </CardContent>
      </Card>
      
      {/* FAQs */}
      <Card>
        <CardHeader>
          <CardTitle>Frequently Asked Questions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <h4 className="font-medium">Can I change plans later?</h4>
            <p className="text-sm text-muted-foreground">
              Yes, you can upgrade, downgrade, or cancel your subscription at any time through your account settings.
            </p>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium">How is my data protected?</h4>
            <p className="text-sm text-muted-foreground">
              We use bank-level encryption to secure your data. Our platform never stores your private keys and uses 
              read-only API access to track your portfolio.
            </p>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium">Are there any refunds?</h4>
            <p className="text-sm text-muted-foreground">
              We offer a 7-day money-back guarantee for all new Pro and Enterprise subscriptions.
            </p>
          </div>
          
          <div className="space-y-2">
            <h4 className="font-medium">What payment methods are accepted?</h4>
            <p className="text-sm text-muted-foreground">
              We accept credit/debit cards, PayPal, and crypto payments including BTC, ETH, and USDC.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}