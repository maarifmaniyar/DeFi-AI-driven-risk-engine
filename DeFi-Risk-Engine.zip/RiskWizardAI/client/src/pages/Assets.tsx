import { useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { usePortfolio } from "@/lib/stores/usePortfolio";
import { Progress } from "@/components/ui/progress";
import { ArrowDown, ArrowUp, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function Assets() {
  const { loadPortfolioData, assets, assetTypes, portfolioValue } = usePortfolio();
  
  useEffect(() => {
    loadPortfolioData();
  }, [loadPortfolioData]);
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Assets</h2>
          <p className="text-muted-foreground">
            Manage and monitor your portfolio assets
          </p>
        </div>
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search assets..."
            className="w-full pl-8 focus-visible:ring-cyan-500"
          />
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Asset Breakdown</CardTitle>
          <CardDescription>
            Complete list of assets in your portfolio
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Asset</TableHead>
                <TableHead>Price</TableHead>
                <TableHead>Holdings</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Change (24h)</TableHead>
                <TableHead>Allocation</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assets.map((asset) => (
                <TableRow key={asset.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <div className="h-9 w-9 rounded-full bg-muted flex items-center justify-center mr-2">
                        {asset.symbol.substring(0, 1)}
                      </div>
                      <div>
                        <div>{asset.name}</div>
                        <div className="text-xs text-muted-foreground">{asset.symbol}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>${asset.price.toLocaleString()}</TableCell>
                  <TableCell>{asset.quantity.toLocaleString()} {asset.symbol}</TableCell>
                  <TableCell>${asset.value.toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      {asset.change >= 0 ? (
                        <ArrowUp className="mr-1 h-4 w-4 text-green-500" />
                      ) : (
                        <ArrowDown className="mr-1 h-4 w-4 text-red-500" />
                      )}
                      <span className={asset.change >= 0 ? "text-green-500" : "text-red-500"}>
                        {Math.abs(asset.change)}%
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col space-y-1">
                      <span className="text-xs">{((asset.value / portfolioValue) * 100).toFixed(2)}%</span>
                      <Progress value={(asset.value / portfolioValue) * 100} className="h-1" />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Asset Categories</CardTitle>
          <CardDescription>
            Distribution by asset category and risk level
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Asset Type</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Percentage</TableHead>
                <TableHead>Risk Level</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {assetTypes.map((type) => (
                <TableRow key={type.id}>
                  <TableCell className="font-medium">{type.name}</TableCell>
                  <TableCell>${type.value.toLocaleString()}</TableCell>
                  <TableCell>{type.percentage.toFixed(2)}%</TableCell>
                  <TableCell>
                    <span className={
                      type.riskLevel === 'Low' ? 'text-green-500' :
                      type.riskLevel === 'Medium' ? 'text-yellow-500' :
                      'text-red-500'
                    }>
                      {type.riskLevel}
                    </span>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}