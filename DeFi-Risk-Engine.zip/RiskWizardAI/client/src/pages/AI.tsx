import VoiceAssistant from "@/components/AI/VoiceAssistant";
import MarketScenarioSimulator from "@/components/AI/MarketScenarioSimulator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function AI() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">AI Features</h2>
        <p className="text-muted-foreground">
          Voice assistant and AI-powered market simulations
        </p>
      </div>
      
      <Tabs defaultValue="voice" className="space-y-4">
        <TabsList>
          <TabsTrigger value="voice">Voice Assistant</TabsTrigger>
          <TabsTrigger value="simulation">Market Scenario Simulator</TabsTrigger>
        </TabsList>
        
        <TabsContent value="voice" className="space-y-4">
          <VoiceAssistant />
        </TabsContent>
        
        <TabsContent value="simulation" className="space-y-4">
          <MarketScenarioSimulator />
        </TabsContent>
      </Tabs>
    </div>
  );
}