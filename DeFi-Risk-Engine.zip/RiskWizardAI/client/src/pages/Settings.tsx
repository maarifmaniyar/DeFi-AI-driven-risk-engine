import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useState } from "react";
import { Moon, Sun, Bell, Eye, EyeOff, Save, Wallet } from "lucide-react";
import { useTheme } from "next-themes";
import { useWallet } from "@/lib/stores/useWallet";
import { useAudio } from "@/lib/stores/useAudio";

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const { isConnected, address } = useWallet();
  const { isMuted, toggleMute } = useAudio();
  const [showSecret, setShowSecret] = useState(false);
  
  const shortenAddress = (addr: string) => {
    return addr ? `${addr.slice(0, 6)}...${addr.slice(-4)}` : '';
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground">
          Manage your account settings and preferences
        </p>
      </div>
      
      <Tabs defaultValue="general" className="space-y-4">
        <TabsList>
          <TabsTrigger value="general">General</TabsTrigger>
          <TabsTrigger value="account">Account</TabsTrigger>
          <TabsTrigger value="wallet">Wallet</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>
        
        <TabsContent value="general" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>
                Customize how the application looks and behaves
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="theme">Theme</Label>
                  <div className="text-sm text-muted-foreground">
                    Choose between light and dark mode
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant={theme === "light" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTheme("light")}
                  >
                    <Sun className="mr-2 h-4 w-4" />
                    Light
                  </Button>
                  <Button
                    variant={theme === "dark" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setTheme("dark")}
                  >
                    <Moon className="mr-2 h-4 w-4" />
                    Dark
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="sound">Sound Effects</Label>
                  <div className="text-sm text-muted-foreground">
                    Enable or disable sound effects
                  </div>
                </div>
                <Switch id="sound" checked={!isMuted} onCheckedChange={toggleMute} />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="animations">Animations</Label>
                  <div className="text-sm text-muted-foreground">
                    Enable or disable UI animations
                  </div>
                </div>
                <Switch id="animations" defaultChecked />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Dashboard Preferences</CardTitle>
              <CardDescription>
                Customize your dashboard layout and content
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="default-view">Default View</Label>
                  <div className="text-sm text-muted-foreground">
                    Choose your default dashboard view
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm">Overview</Button>
                  <Button variant="outline" size="sm">Risk</Button>
                  <Button variant="outline" size="sm">Assets</Button>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="auto-refresh">Auto-Refresh Data</Label>
                  <div className="text-sm text-muted-foreground">
                    Automatically refresh portfolio data
                  </div>
                </div>
                <Switch id="auto-refresh" defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="account" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>
                Update your account details
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Display Name</Label>
                <Input id="name" defaultValue="John Doe" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" type="email" defaultValue="john.doe@example.com" />
              </div>
              
              <Button>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Subscription Plan</CardTitle>
              <CardDescription>
                Manage your subscription and billing
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h4 className="font-medium">Current Plan: Free</h4>
                  <p className="text-sm text-muted-foreground">
                    Basic portfolio tracking and risk analysis
                  </p>
                </div>
                <Button>Upgrade to Pro</Button>
              </div>
              
              <div className="rounded-md bg-muted p-4">
                <h4 className="font-medium mb-2">Pro Plan Benefits:</h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                  <li>• Advanced risk analysis tools</li>
                  <li>• Protocol security audits</li>
                  <li>• Real-time market alerts</li>
                  <li>• Custom risk models</li>
                  <li>• Priority customer support</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="wallet" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Connected Wallets</CardTitle>
              <CardDescription>
                Manage your blockchain wallet connections
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isConnected ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-cyan-400 to-blue-500 mr-3"></div>
                      <div>
                        <div className="font-medium">{shortenAddress(address)}</div>
                        <div className="text-sm text-muted-foreground">Ethereum Mainnet</div>
                      </div>
                    </div>
                    <Button variant="destructive" onClick={() => useWallet.getState().disconnect()}>
                      Disconnect
                    </Button>
                  </div>
                  
                  <div className="rounded-md bg-muted p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Address Verification</h4>
                      <Badge>Verified</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      This wallet has been verified for enhanced security.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 space-y-4">
                  <Wallet className="h-12 w-12 text-muted-foreground" />
                  <div className="text-center">
                    <h4 className="font-medium">No Wallets Connected</h4>
                    <p className="text-sm text-muted-foreground mb-4">
                      Connect your wallet to view your portfolio and risk assessment
                    </p>
                    <Button onClick={() => useWallet.getState().connect()}>
                      Connect Wallet
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="notifications" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Manage how you receive alerts and notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="price-alerts">Price Alerts</Label>
                  <div className="text-sm text-muted-foreground">
                    Receive notifications for significant price changes
                  </div>
                </div>
                <Switch id="price-alerts" defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="security-alerts">Security Alerts</Label>
                  <div className="text-sm text-muted-foreground">
                    Get notified about security issues in your portfolio
                  </div>
                </div>
                <Switch id="security-alerts" defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="market-alerts">Market Intelligence</Label>
                  <div className="text-sm text-muted-foreground">
                    Receive market news and analysis
                  </div>
                </div>
                <Switch id="market-alerts" defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label htmlFor="email-notifications">Email Notifications</Label>
                  <div className="text-sm text-muted-foreground">
                    Receive notifications via email
                  </div>
                </div>
                <Switch id="email-notifications" defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Manage your account security preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <div className="relative">
                  <Input
                    id="current-password"
                    type={showSecret ? "text" : "password"}
                    defaultValue="password123"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowSecret(!showSecret)}
                  >
                    {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input id="new-password" type="password" />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input id="confirm-password" type="password" />
              </div>
              
              <Button>
                <Save className="mr-2 h-4 w-4" />
                Update Password
              </Button>
              
              <div className="pt-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <Label htmlFor="two-factor">Two-Factor Authentication</Label>
                    <div className="text-sm text-muted-foreground">
                      Add an extra layer of security to your account
                    </div>
                  </div>
                  <Switch id="two-factor" />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Badge component since we used it but hadn't imported
function Badge({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold ${className || 'bg-primary text-primary-foreground'}`}>
      {children}
    </span>
  );
}