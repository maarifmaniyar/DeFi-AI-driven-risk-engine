import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PlusCircle, Link, AlertTriangle, CreditCard, Building, Landmark } from "lucide-react";

export default function Banking() {
  // Sample connected bank accounts
  const connectedBanks = [
    { id: 1, name: "Metro Bank", accountType: "Checking", accountNumber: "****4582", balance: 12845.32, lastUpdated: "2023-05-15" },
    { id: 2, name: "Nationwide", accountType: "Savings", accountNumber: "****7612", balance: 25630.18, lastUpdated: "2023-05-15" }
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4 md:flex-row md:items-center md:justify-between md:space-y-0">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">Banking</h2>
          <p className="text-muted-foreground">
            Manage your traditional banking connections
          </p>
        </div>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Connect New Account
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Connected Bank Accounts</CardTitle>
          <CardDescription>
            Your linked traditional banking accounts
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Bank</TableHead>
                <TableHead>Account Type</TableHead>
                <TableHead>Account Number</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Last Updated</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {connectedBanks.map((bank) => (
                <TableRow key={bank.id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center">
                      <Building className="h-5 w-5 mr-2 text-primary" />
                      <div>{bank.name}</div>
                    </div>
                  </TableCell>
                  <TableCell>{bank.accountType}</TableCell>
                  <TableCell>{bank.accountNumber}</TableCell>
                  <TableCell>${bank.balance.toLocaleString()}</TableCell>
                  <TableCell>{bank.lastUpdated}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm">
                      Refresh
                    </Button>
                    <Button variant="ghost" size="sm">
                      Disconnect
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Connect a Bank Account</CardTitle>
            <CardDescription>
              Securely link your traditional banking accounts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-md border p-4">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-primary/10 p-2">
                    <Landmark className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">Connect via Open Banking</p>
                    <p className="text-sm text-muted-foreground">
                      Securely connect your accounts using open banking APIs
                    </p>
                  </div>
                  <Button>
                    <Link className="mr-2 h-4 w-4" />
                    Connect
                  </Button>
                </div>
              </div>
              
              <div className="rounded-md border p-4">
                <div className="flex items-center space-x-4">
                  <div className="rounded-full bg-primary/10 p-2">
                    <CreditCard className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm font-medium">Connect Credit Cards</p>
                    <p className="text-sm text-muted-foreground">
                      Link your credit cards to track spending and balances
                    </p>
                  </div>
                  <Button>
                    <Link className="mr-2 h-4 w-4" />
                    Connect
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Banking Integration Benefits</CardTitle>
            <CardDescription>
              Why connect your traditional banking accounts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <div className="mt-0.5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Comprehensive Risk Analysis</h4>
                  <p className="text-xs text-muted-foreground">
                    View your complete financial picture including both crypto and traditional assets
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="mt-0.5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Diversification Insights</h4>
                  <p className="text-xs text-muted-foreground">
                    Get recommendations on how to better diversify across traditional and crypto assets
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="mt-0.5">
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-green-500">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                  </svg>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Tax Planning Optimization</h4>
                  <p className="text-xs text-muted-foreground">
                    Simplify tax preparation with consolidated financial data
                  </p>
                </div>
              </div>
            </div>
            
            <div className="mt-4 rounded-md bg-yellow-500/10 p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 text-yellow-500" />
                <div>
                  <h4 className="text-sm font-medium text-yellow-500">Security Note</h4>
                  <p className="text-xs text-muted-foreground">
                    We use bank-level encryption and secure read-only access. We never store your credentials.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}