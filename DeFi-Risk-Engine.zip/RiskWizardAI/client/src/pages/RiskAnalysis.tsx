import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useRiskAnalysis } from "@/lib/stores/useRiskAnalysis";
import { useEffect } from "react";

export default function RiskAnalysis() {
  const { loadRiskData, riskMetrics, volatilityByAsset, protocolRiskMap } = useRiskAnalysis();
  
  useEffect(() => {
    loadRiskData();
  }, [loadRiskData]);
  
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">Risk Analysis</h2>
        <p className="text-muted-foreground">
          In-depth analysis of your portfolio's risk factors
        </p>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {riskMetrics.map((metric) => (
          <Card key={metric.id}>
            <CardHeader className="pb-2">
              <CardTitle className="text-md">{metric.name}</CardTitle>
              <CardDescription>
                {metric.description}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-baseline space-x-2">
                <span className="text-2xl font-bold">{metric.value}</span>
                <span className={`text-xs ${
                  metric.status === 'good' ? 'text-green-500' : 
                  metric.status === 'warning' ? 'text-yellow-500' : 
                  'text-red-500'
                }`}>
                  {metric.interpretation}
                </span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Protocol Risk Analysis</CardTitle>
          <CardDescription>
            Risk assessment of DeFi protocols in your portfolio
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {protocolRiskMap.map((protocol) => (
              <Card key={protocol.id} className="border border-muted">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">{protocol.name}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Risk Score:</span>
                    <span className={`font-medium ${
                      protocol.riskScore < 30 ? 'text-green-500' :
                      protocol.riskScore < 70 ? 'text-yellow-500' :
                      'text-red-500'
                    }`}>
                      {protocol.riskScore}/100
                    </span>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-sm">Exposure:</span>
                    <span className="font-medium">${protocol.exposure.toLocaleString()}</span>
                  </div>
                  <div className="mt-2 h-1.5 w-full bg-secondary rounded-full">
                    <div 
                      className="h-1.5 rounded-full" 
                      style={{ 
                        width: `${protocol.riskScore}%`,
                        background: `linear-gradient(90deg, 
                          ${protocol.riskScore < 30 ? '#10b981' : 
                            protocol.riskScore < 70 ? '#f59e0b' : 
                            '#ef4444'} 0%, 
                          ${protocol.riskScore < 30 ? '#10b981' : 
                            protocol.riskScore < 70 ? '#f59e0b' : 
                            '#ef4444'} 100%)`
                      }}
                    ></div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}